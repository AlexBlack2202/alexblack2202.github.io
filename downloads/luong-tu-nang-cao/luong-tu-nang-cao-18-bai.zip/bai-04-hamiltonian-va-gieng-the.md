# Bài 04 · Kéo giếng thế rộng gấp đôi có làm năng lượng giảm một nửa?

## Đặt vấn đề

Mình căng một sợi dây giữa hai đinh. Với hai đầu cố định, một nửa bước sóng có thể nằm vừa khít giữa hai đinh, hoặc hai nửa, hoặc ba. Hình ấy gợi đúng điều kiện biên cho một bài lượng tử. Nhưng nếu bắt chước dây đàn và đoán năng lượng tăng đều theo số nửa bước sóng, mình sẽ đoán sai.

Xét hạt khối lượng $m$, chuyển động một chiều trong giếng vô hạn $0<x<L$. Thế năng trong giếng bằng 0, hàm sóng bằng 0 tại hai thành. Trong đại số bạn đã giải $Hv=Ev$ cho một cột số. Bây giờ Hamiltonian tác động lên một **hàm** bằng cách lấy đạo hàm bậc hai:
$$
-\frac{\hbar^2}{2m}\phi''(x)=E\phi(x),\qquad \phi(0)=\phi(L)=0.
$$
Thử $\sin(kx)$: đạo hàm hai lần trả về $-k^2\sin(kx)$. Hàm cos bị điều kiện ở đầu trái loại khỏi nghiệm tổng quát với $E>0$. Đầu phải yêu cầu $kL=n\pi$. Với $n=0$ nghiệm thỏa hai đầu chỉ còn hàm bằng 0, không thể chuẩn hóa. Các nghiệm âm của $k$ lặp lại cùng trạng thái khác dấu. Năng lượng dương vì kỳ vọng động năng tỉ lệ với tích phân $|\phi'|^2$ dưới hai điều kiện biên này.
$$
\phi_n(x)=\sqrt{2/L}\sin(n\pi x/L),\qquad E_n=\frac{\hbar^2\pi^2 n^2}{2mL^2},\qquad n=1,2,\ldots
$$
Hệ số đầu xuất hiện vì diện tích dưới $\sin^2$ trên đoạn bằng $L/2$. Ký hiệu $\hbar$ là hằng số Planck rút gọn; nếu $m$ tính theo kg và $L$ theo mét, $E_n$ có đơn vị joule. Cố định mức $n$ rồi tăng $L$ gấp đôi, năng lượng còn một phần tư. Cố định $L$ rồi tăng $n$ từ 1 lên 2, năng lượng tăng gấp bốn.

![Hai hàm riêng trong giếng thế](hinh/hinh-04.webp)

*Đường thứ hai có thêm một nút bên trong. Ở cùng độ dài giếng, hai nửa sóng làm trị tuyệt đối của đạo hàm bậc hai lớn hơn tại các đỉnh. độ cong liên hệ trực tiếp với động năng trong phương trình.*

## Đưa hàm liên tục trở lại thành ma trận

Chọn $M$ điểm trong giếng, cách nhau $h=L/(M+1)$. Tại điểm $j$, thay đạo hàm hai bằng $(v_{j+1}-2v_j+v_{j-1})/h^2$. Trong đơn vị năng lượng $\hbar^2/(2mL^2)$, ma trận có đường chéo $2(L/h)^2$ và hai đường chéo kề bằng $-(L/h)^2$. Với chỉ hai điểm trong, ma trận là 9 lần ma trận có đường chéo 2, ngoài chéo −1. Trị riêng thấp nhất bằng 9, khá gần $\pi^2\simeq9{,}870$. Trong sổ thực hành, tăng số điểm rồi kiểm tra chính sai số đó.

## Nếu thành giếng chỉ cao hữu hạn thì sao?

Giả sử hai thành đủ dày để mô hình hóa vùng bên ngoài bằng một thế năng không đổi $V_0$. Hạt đang ở một trạng thái liên kết có năng lượng $E<V_0$. Bây giờ bạn đi từ mép phải sang ngoài giếng một đoạn $d$. Hàm sóng ở vùng ấy thỏa $\phi''=\kappa^2\phi$, với $\kappa=\sqrt{2m(V_0-E)}/\hbar$ có đơn vị nghịch đảo mét. Nghiệm tăng theo khoảng cách sẽ làm tích phân xác suất vô hạn, nên chỉ giữ nghiệm giảm theo $e^{-\kappa d}$.

Ở cách mép một đoạn $1/\kappa$, biên độ còn $1/e$ lần giá trị tại mép. Vì máy dò nhạy với bình phương môđun, **mật độ** ở đó còn $e^{-2}\approx0{,}135$ lần mật độ ngay tại mép. Đây là tỉ số tại hai vị trí. Muốn biết bao nhiêu phần trăm số lượt tìm thấy hạt ở ngoài, ta còn phải tích phân phần đuôi. Trong giếng hữu hạn, độ cao thành cũng tham gia quyết định các mức năng lượng. Quy tắc tăng gấp đôi bề rộng làm năng lượng còn một phần tư ở hình trên áp dụng cho giếng vô hạn.

## Kiểm chứng bằng Python

Hãy nhìn hiệu so với π² khi giảm bước lưới. Đây là sai số rời rạc hóa ngay cả khi phép giải trị riêng đã đủ chính xác.

```python
import numpy as np
for M in (2, 8, 32, 96):
    side = -np.ones(M - 1)
    H = (M + 1)**2 * (2*np.eye(M) + np.diag(side, 1) + np.diag(side, -1))
    E1 = np.linalg.eigvalsh(H)[0]
    print(f"{M:2} điểm: E₁ = {E1:.6f}, sai số = {abs(E1-np.pi**2):.6f}")
```

Kết quả của lần chạy trong sổ thực hành:

```text
2 điểm: E₁ = 9.000000, sai số = 0.869604
 8 điểm: E₁ = 9.769795, sai số = 0.099809
32 điểm: E₁ = 9.862153, sai số = 0.007452
96 điểm: E₁ = 9.868742, sai số = 0.000863
```

## Tự thử

Tại sao bài toán lưới với hai điểm chỉ cho hai mức dù giếng lý tưởng có vô hạn mức?

**Lời giải.** Hai giá trị ở hai điểm tạo không gian hai chiều. Một hàm có nhiều nút hơn có thể dao động giữa các điểm mà lưới không phân biệt được. Muốn khảo sát mức cao, cần kiểm tra hội tụ riêng ở mức ấy.

## Tham khảo

- Shivakumar Hunagund, “Electronic and Optical Properties of Quantum Nano-Structures: Quantum Well Systems”, chương 4 trong *Principles and Applications of Quantum Computing Using Essential Math*, mục “The Finite Well”, trang PDF 81.
- Griffiths & Schroeter, *Introduction to Quantum Mechanics*, ấn bản 3, chương 2. [Mục lục của Cambridge](https://assets.cambridge.org/97811071/89638/frontmatter/9781107189638_frontmatter.pdf).
- [OpenStax · Nghiệm cho hạt trong giếng thế](https://openstax.org/books/university-physics-volume-3/pages/7-4-the-quantum-particle-in-a-box).

Ôn từ lớp nhập môn: [Biên độ 3/5 cho xác suất bao nhiêu?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-09-tinh-xac-suat-tu-bien-do/) · [Làm sao vẽ pha bằng một mũi tên quay?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-13-pha-cua-bien-do-phuc/).

[Về mục lục](muc-luc.md)
