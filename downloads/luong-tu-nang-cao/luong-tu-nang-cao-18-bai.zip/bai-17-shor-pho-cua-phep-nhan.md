# Bài 17 · Vì sao bài tìm bậc của 2 theo mô-đun 21 sinh ra sáu pha?

## Đặt vấn đề

Chiếc đồng hồ của mình có 21 vạch. Từ vạch 1, mỗi tiếng tích mình nhân số đang đứng với 2 rồi lấy dư theo 21. Sáu tiếng đầu cho $1,2,4,8,16,11$, tiếng kế tiếp trở lại 1. Nếu mình chỉ giao bạn một mạch thực hiện được một bước đi mà giấu độ dài vòng, bạn có thể tìm vòng bằng pha ở bài trước như thế nào?

Đặt $U|z\rangle=|2z\bmod21\rangle$ trên 21 nhãn hợp lệ. Vì 2 nguyên tố cùng nhau với 21, phép nhân là song ánh. Dùng năm qubit có 32 nhãn; ta chọn giữ nguyên các nhãn 21 đến 31 để cả ma trận là hoán vị. Trên quỹ đạo bắt đầu từ 1, viết $z_j=2^j\bmod21$. Khi ấy $U|z_j\rangle=|z_{j+1}\rangle$, chỉ số lấy theo vòng độ dài $r=6$.
$$
|u_s\rangle=\frac1{\sqrt r}\sum_{j=0}^{r-1}e^{-2\pi i sj/r}|z_j\rangle,\qquad U|u_s\rangle=e^{2\pi i s/r}|u_s\rangle .
$$
Đổi tên chỉ số $j+1$ thành $k$ trong tổng, số mũ chứa $k-1$ nên kéo ra được pha **dương** $2\pi s/r$. Cộng tất cả $r$ vectơ riêng rồi chia $\sqrt r$, các nhãn $j\ne0$ triệt tiêu, còn lại đúng $|z_0\rangle=|1\rangle$. Vậy chuẩn bị một nhãn dễ dàng là 1 đã đặt trọng số $1/r$ lên mỗi pha $s/r$. Mình không cần biết trước $r$ để chuẩn bị đầu vào hay dựng phép nhân.

## Máy có thể trả về một nhãn gần đỉnh

Dùng $t=6$ bit đếm để nhìn rõ hiệu ứng trên một ví dụ nhỏ. Lưới có $Q=64$ nhãn, trong khi các đỉnh nằm gần $64s/6$. Với $s=1$ điểm lý tưởng ở 10,67; nhãn 11 có cơ hội xuất hiện. Với $s=3$ đỉnh đúng 32. Phân bố toàn bộ là trung bình của sáu phân bố Fourier từ bài trước. Ta cộng **xác suất** ở bước cuối vì các thành phần pha đi với sáu trạng thái đích trực giao.

![Phổ tìm bậc với sáu bit đếm](hinh/hinh-17.webp)

*Vùng quanh nhãn 11 và 53 bị trải rộng, còn nhịp bằng nửa vòng có đỉnh đúng tại 32. Trong phổ gộp, các đuôi của pha khác cũng đóng góp vào một số nhãn.*

Sổ thực hành dựng một bảng biên độ hai thanh ghi trực tiếp từ $x\mapsto2^x\bmod21$, làm Fourier ngược ở trục $x$ và cộng xác suất theo nhãn số dư. Đây là mô phỏng nhỏ tốn bộ nhớ theo số nhãn của cả hai thanh ghi. Cách dựng bảng cho phép đối chiếu phân bố ở hình mà không nhét số 6 vào mạch như một đáp án biết sẵn.

## Kiểm chứng bằng Python

Độ dài chu kỳ được quyết định bởi phép nhân. Bạn có thể đổi cơ số và xem các đỉnh di chuyển. Bảng đầu vào được dựng từ chính số dư.

```python
import numpy as np
Q, N = 64, 21
joint = np.zeros((Q, 32))
for x in range(Q):
    joint[x, pow(2, x, N)] = 1/np.sqrt(Q)
spectrum = np.abs(np.fft.fft(joint, axis=0, norm="ortho"))**2
p = spectrum.sum(axis=1)
print("P(11), P(32), P(53):", np.round(p[[11,32,53]], 6))
assert np.isclose(p.sum(), 1)
```

Kết quả của lần chạy trong sổ thực hành:

```text
P(11), P(32), P(53): [0.114196 0.166992 0.114196]
```

## Tự thử

Tại sao không chọn cơ số 3 rồi vẫn định nghĩa cổng bằng cách nhân 3 theo mô-đun 21?

**Lời giải.** Hai nhãn 0 và 7 cùng bị gửi về 0. Các cột không còn trực giao. Nhưng phép kiểm tra cổ điển $\gcd(3,21)=3$ đã tìm thấy một ước ngay ở bước chọn cơ số.

## Tham khảo

- Nielsen & Chuang, *Quantum Computation and Quantum Information*, bản kỷ niệm 10 năm, chương 5. [Mục lục của Cambridge](https://assets.cambridge.org/97811070/02173/toc/9781107002173_toc.pdf).
- [IBM Quantum Learning · Ước lượng pha và phân tích thừa số](https://eu-de.quantum.cloud.ibm.com/learning/en/courses/fundamentals-of-quantum-algorithms/phase-estimation-and-factoring/introduction).

Ôn từ lớp nhập môn: [Số dư của 2ᵏ khi chia cho 15 lặp thế nào?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-37-chu-ky-cua-luy-thua-theo-modun/) · [Làm sao biến một dãy lặp thành các đỉnh tần số?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-40-tu-chu-ky-den-dinh-tan-so/).

[Về mục lục](muc-luc.md)
