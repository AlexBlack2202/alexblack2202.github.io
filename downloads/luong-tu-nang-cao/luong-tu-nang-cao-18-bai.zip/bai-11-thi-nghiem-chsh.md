# Bài 11 · Bốn cặp hướng đo nào cho giá trị CHSH bằng 2√2?

## Đặt vấn đề

Mình đặt bốn mảnh băng dính đánh dấu các góc trên vòng tròn. Hai mảnh của An ở 0° và 90°, hai mảnh của Bình ở 45° và −45°. Nếu chọn nhầm dấu của mảnh cuối, tổng CHSH có thể tụt hẳn dù nguồn vẫn phát đúng trạng thái Bell. Bạn có thể tìm ra sai sót trước khi viết mạch.

Hai bên dùng $M(a)=Z\cos a+X\sin a$ trong mặt phẳng $xz$, với kết quả ±1. Ở trạng thái $\Phi^+$, hai phép lật $XX$ đổi chỗ hai nhánh, còn $ZZ$ giữ dấu cả hai nhánh. Kỳ vọng của cả hai bằng 1. Các tích chéo $XZ,ZX$ đưa trạng thái sang không gian sinh bởi 01 và 10 nên kỳ vọng bằng 0. Khai triển tích hai phép đo chỉ còn
$$
E(a,b)=\langle M(a)\otimes M(b)\rangle=\cos a\cos b+\sin a\sin b=\cos(a-b).
$$
Ba chênh góc đầu có cos bằng $1/\sqrt2$. Chênh cuối giữa 90° và −45° là 135°, có cos bằng $-1/\sqrt2$. Với quy ước trừ hạng cuối ở bài trước, $S=4/\sqrt2=2\sqrt2$. Nếu dùng trạng thái singlet hay đổi nhãn một đầu dò, phải tính lại quy ước dấu.

![Bốn tương quan theo cặp góc](hinh/hinh-11.webp)

*Cột thứ tư nằm dưới 0 trước khi đưa vào tổng CHSH. Chính dấu trừ trong tổng đổi đóng góp của cột ấy thành số dương.*

## Sổ thực hành phải giữ bốn nhóm số đếm

Từ mỗi nhóm, tính $E=(N_{00}+N_{11}-N_{01}-N_{10})/N$. Hai bit giống nhau cho tích +1. Với 400 cặp độc lập cho **mỗi** cấu hình, phương sai ước lượng một tương quan là $(1-E^2)/400=1/800$. Nếu bốn nhóm độc lập, độ lệch chuẩn của tổng là $\sqrt{4/800}\approx0{,}071$. Trong notebook, thử tính cả xác suất lý tưởng và tương quan lấy mẫu. Máy mô phỏng chuẩn bị đúng trạng thái theo giả thiết của mình; muốn kết luận về tự nhiên phải dùng dữ liệu thực nghiệm cùng cách xử lý các kẽ hở thực nghiệm.

## Kiểm chứng bằng Python

Mỗi dòng ghi một cặp góc và bốn số đếm. Hãy lấy máy tính tay dựng lại riêng tương quan ở dòng cuối trước khi xem tổng.

```python
import numpy as np
rng = np.random.default_rng(31)
A, B = [0, 90], [45, -45]
signs = np.array([1, 1, 1, -1])
ideal, sample = [], []
for a in A:
    for b in B:
        E = np.cos(np.deg2rad(a-b))
        # Cặp Bell có phân bố biên đều. Thứ tự kết quả: 00, 01, 10, 11.
        probabilities = (1 + E*np.array([1,-1,-1,1]))/4
        counts = rng.multinomial(400, probabilities)
        ideal.append(E)
        sample.append(counts @ [1,-1,-1,1]/400)
        print(a, b, counts.tolist())
print("S lý tưởng và S mẫu:", signs @ ideal, signs @ sample)
assert np.isclose(signs @ ideal, 2*np.sqrt(2))
```

Kết quả của lần chạy trong sổ thực hành:

```text
0 45 [188, 29, 26, 157]
0 -45 [159, 30, 35, 176]
90 45 [182, 25, 26, 167]
90 -45 [19, 179, 171, 31]
S lý tưởng và S mẫu: 2.82842712474619 2.895
```

## Tự thử

Nếu Bình đặt cả hai vạch ở 45°, $S$ còn bao nhiêu?

**Lời giải.** Hai hạng của $A_1$ bằng nhau và triệt tiêu. Còn $2E(0,45^\circ)=\sqrt2$. Cặp Bell vẫn rối. Một cấu hình đo cho kết quả dưới 2 chưa chứng minh rằng nguồn đã mất rối.

## Tham khảo

- Nielsen & Chuang, *Quantum Computation and Quantum Information*, bản kỷ niệm 10 năm, chương 2. [Mục lục của Cambridge](https://assets.cambridge.org/97811070/02173/toc/9781107002173_toc.pdf).
- [IBM Quantum Learning · Trò chơi CHSH](https://eu-de.quantum.cloud.ibm.com/learning/en/courses/basics-of-quantum-information/entanglement-in-action/chsh-game).

Ôn từ lớp nhập môn: [Hai cổng tạo ra một cặp Bell bằng cách nào?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-28-tao-cap-bell/) · [Hai phong bì giống nhau giải thích được phần nào của cặp Bell?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-29-tuong-quan-cua-cap-bell/).

[Về mục lục](muc-luc.md)
