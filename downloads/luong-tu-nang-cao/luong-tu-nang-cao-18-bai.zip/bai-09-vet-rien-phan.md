# Bài 09 · Theo dõi riêng một nửa cặp Bell thì mất thông tin gì?

## Đặt vấn đề

Mình gửi cho An và Bình mỗi người một phong bì. Họ mở riêng, cả hai đều báo “một nửa số lần là 0”. Nếu mình xếp nhầm thứ tự lượt ở hai cuốn sổ thì không ai ghép lại được ai trùng ai. Với qubit, bỏ một phần của hệ còn có thể làm mất cả thông tin pha mà hai cuốn sổ Z chưa bao giờ chứa.

Nguồn thứ nhất chuẩn bị $|\Phi^+\rangle=(|00\rangle+|11\rangle)/\sqrt2$. Nguồn thứ hai chọn ngẫu nhiên $|00\rangle$ hoặc $|11\rangle$, mỗi loại một nửa. Trong cơ sở theo thứ tự 00, 01, 10, 11, hai ma trận mật độ đều có phần tử đường chéo $(1/2,0,0,1/2)$. Với trạng thái thuần, lấy tích ngoài của cột với liên hợp chuyển vị tạo thêm hai ô ở góc đối diện, đều bằng $1/2$. Với nguồn ngẫu nhiên, lấy trung bình hai tích ngoài riêng lẻ, hai ô góc ấy bằng 0.
$$
(\rho_A)_{a,a'}=\sum_{b=0}^1\rho_{ab,a'b}.
$$
Chẳng hạn, ô $(0,0)$ của An bằng $\rho_{00,00}+\rho_{01,01}=1/2$. Ô $(0,1)$ cần $\rho_{00,10}+\rho_{01,11}=0$. Hai ô góc đặc biệt có nhãn Bình khác nhau giữa hàng và cột nên không lọt vào tổng. Cả hai nguồn cho $\rho_A=I/2$. Bất cứ phép đo nào trên riêng An đều cho cùng thống kê ở hai nguồn.

![Hai ma trận mật độ của cặp qubit](hinh/hinh-09.webp)

*Hai ô màu ở ngoài đường chéo là nơi phép đo chung có thể khai thác. Đo ngay hai bit Z chỉ đọc bốn ô trên đường chéo của từng bảng.*

## Một con số cho cả cặp, một con số cho riêng An

Bạn thử lấy bình phương ma trận mật độ rồi cộng đường chéo. Đại lượng thu được gọi là độ tinh khiết, $\gamma=\mathrm{Tr}(\rho^2)$. Với cả cặp Bell, $\rho=|\Phi^+\rangle\langle\Phi^+|$ nên $\rho^2=\rho$ và $\gamma=1$. Với nguồn tung xu chọn 00 hoặc 11, bình phương ma trận chéo để lại hai số $1/4$ trên đường chéo. Độ tinh khiết của cả cặp chỉ bằng $1/2$.

Giờ lặp phép tính trên qubit của riêng An. Cả hai thí nghiệm đều cho $\rho_A=I/2$, thành ra $\mathrm{Tr}(\rho_A^2)=1/2$. Từ số đo cục bộ ấy, An không thể biết người gửi đã tung xu hay đã chuẩn bị cặp Bell. Nếu người gửi bảo đảm **toàn hệ ở trạng thái thuần**, kết luận sẽ mạnh hơn. Một trạng thái thuần dạng tích luôn cho trạng thái con thuần, nên khi đó độ tinh khiết cục bộ nhỏ hơn một chứng tỏ hai phần có rối.

## Kiểm chứng bằng Python

Phép reshape tách chỉ số hàng thành hai nhãn và chỉ số cột thành hai nhãn. Phải lấy vết trên đúng hai trục của Bình.

```python
import numpy as np
psi = np.array([1, 0, 0, 1])/np.sqrt(2)
bell = np.outer(psi, psi.conj())
mixed = np.diag([0.5, 0, 0, 0.5])
X = np.array([[0, 1], [1, 0]])
for rho in (bell, mixed):
    local = np.trace(rho.reshape(2, 2, 2, 2), axis1=1, axis2=3)
    print("ρ_A =", local.tolist(), "  ⟨XX⟩ =", round(np.trace(rho @ np.kron(X, X)), 4))
    assert np.allclose(local, np.eye(2)/2)
```

Kết quả của lần chạy trong sổ thực hành:

```text
ρ_A = [[0.4999999999999999, 0.0], [0.0, 0.4999999999999999]]   ⟨XX⟩ = 1.0
ρ_A = [[0.5, 0.0], [0.0, 0.5]]   ⟨XX⟩ = 0.0
```

## Tự thử

Chọn phép đo $X\otimes X$. Vì sao giá trị kỳ vọng là 1 ở nguồn Bell và 0 ở nguồn tung xu?

**Lời giải.** Phép lật kép tráo 00 với 11, nên giữ nguyên trạng thái Bell có dấu cộng. Trong mỗi thành phần của nguồn tung xu, phép lật đưa trạng thái sang một ket trực giao, nên kỳ vọng bằng 0. Phép đo chung nối đúng hai nhãn mà hai ô góc liên kết. Kết quả này phân biệt hai nguồn cụ thể. để kiểm tra giới hạn của cả một lớp mô hình cục bộ, mình cần bài tiếp.

## Tham khảo

- Stefano Olivares, *A Student’s Guide to Quantum Computing*, mục 2.6–2.8 về ma trận mật độ, vết riêng phần và rối của hai qubit.
- Nielsen & Chuang, *Quantum Computation and Quantum Information*, bản kỷ niệm 10 năm, chương 2. [Mục lục của Cambridge](https://assets.cambridge.org/97811070/02173/toc/9781107002173_toc.pdf).

Ôn từ lớp nhập môn: [Hai cổng tạo ra một cặp Bell bằng cách nào?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-28-tao-cap-bell/) · [Vì sao rối lượng tử không truyền được tin nhắn từ xa?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-30-roi-luong-tu-va-truyen-tin/).

[Về mục lục](muc-luc.md)
