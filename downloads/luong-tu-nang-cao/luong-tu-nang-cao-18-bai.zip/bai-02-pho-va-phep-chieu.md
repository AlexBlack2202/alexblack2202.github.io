# Bài 02 · Máy có thể chỉ một số khác cả hai trị riêng không?

## Đặt vấn đề

Mình chuẩn bị cùng một qubit nhiều lần. Đồng hồ chỉ 1 hoặc 3 đơn vị năng lượng. Người trực máy lại ghi “năng lượng bằng 2”. Bạn sẽ yêu cầu xem một lần đo, hay cả cuốn sổ?

Giả sử thiết bị đo chiếu lý tưởng của đại lượng $A=\epsilon\begin{pmatrix}2&1\\1&2\end{pmatrix}$ với $\epsilon>0$ là một đơn vị năng lượng. Chuẩn bị $\psi=(1,0)^T$. Nhân ma trận với hai đường chéo $u=(1,1)^T/\sqrt2$, $v=(1,-1)^T/\sqrt2$. Hàng đầu cho tổng 3 với $u$ và hiệu 1 với $v$. Hàng sau xác nhận $Au=3\epsilon u$, $Av=\epsilon v$.

## Từ trị riêng tới sổ đo

Tách trạng thái ban đầu thành $(u+v)/\sqrt2$. Hai phép chiếu giữ lại lần lượt $u/\sqrt2$ và $v/\sqrt2$, cùng có bình phương chuẩn bằng $1/2$. Nếu máy vừa báo $3\epsilon$, chia phần được giữ cho chuẩn của nó để có trạng thái sau đo là $u$. Đo lại ngay trên cùng hệ cô lập thì đầu ấy sáng chắc chắn. Nếu làm lại từ bước chuẩn bị, ta lại có hai khả năng.
$$
P_\lambda=\sum_{k:\,a_k=\lambda}|k\rangle\langle k|,\quad p_\lambda=\langle\psi|P_\lambda|\psi\rangle,\quad |\psi_\lambda\rangle=P_\lambda|\psi\rangle/\sqrt{p_\lambda}.
$$
Ở đây các ket là một cơ sở riêng trực chuẩn của $A$; công thức sau cùng dùng khi $p_\lambda>0$. Tổng trên cùng trị riêng quan trọng nếu thiết bị chỉ phân biệt giá trị $\lambda$ mà nhiều vectơ độc lập cùng mang giá trị ấy.

![Phổ năng lượng và giá trị kỳ vọng](hinh/hinh-02.webp)

*Điểm 2 nằm đúng giữa hai cột. Thống kê có thể đặt trung bình ở nơi máy chưa từng ghi một lượt riêng lẻ.*

## Kiểm chứng bằng Python

Một máy có thể chỉ mãi hai mức, dù trung bình là mức nằm giữa chúng. Hai cách đọc kết quả bên dưới tương ứng với hai đại lượng đó.

```python
import numpy as np
A = np.array([[2, 1], [1, 2]])
values, vectors = np.linalg.eigh(A)
p = np.abs(vectors.conj().T @ [1, 0])**2
print("E/ε =", values, "  p =", p, "  trung bình =", values @ p)
assert np.allclose(p, [0.5, 0.5])
```

Kết quả của lần chạy trong sổ thực hành:

```text
E/ε = [1. 3.]   p = [0.5 0.5]   trung bình = 1.9999999999999996
```

## Tự thử

Với cùng nguồn, độ lệch chuẩn của kết quả có bằng 0 khi số lần đo tăng không?

**Lời giải.** Trung bình là $2\epsilon$. Mỗi lần đo lệch khỏi trung bình đúng $\epsilon$ về một phía, nên phương sai là $\epsilon^2$. Sai số chuẩn của **trung bình mẫu** mới giảm thành $\epsilon/\sqrt N$ với $N$ lượt độc lập. Con số 2 trong sổ có nghĩa khi người trực máy ghi rõ đó là trung bình theo đơn vị $\epsilon$.

## Tham khảo

- Griffiths & Schroeter, *Introduction to Quantum Mechanics*, ấn bản 3, chương 3. [Mục lục của Cambridge](https://assets.cambridge.org/97811071/89638/frontmatter/9781107189638_frontmatter.pdf).

Ôn từ lớp nhập môn: [Biên độ 3/5 cho xác suất bao nhiêu?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-09-tinh-xac-suat-tu-bien-do/) · [Một lần đo cho biết bao nhiêu về biên độ?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-12-mot-lan-do-cho-biet-gi-ve-qubit/).

[Về mục lục](muc-luc.md)
