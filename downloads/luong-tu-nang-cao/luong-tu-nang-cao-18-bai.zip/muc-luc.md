# Lượng tử nâng cao cho sinh viên năm ba

Phạm Duy Tùng · 18 bài học và thí nghiệm

![Bìa lớp lượng tử nâng cao](hinh/bia.webp)


Mình có hai chiếc hộp. Bấm nút nào cũng cho một dãy số 0 và 1 trông như tung đồng xu. Nếu đếm thêm một triệu lượt vẫn chẳng phân biệt được hai hộp, liệu có phải mình đang hỏi chúng sai câu? Ở bài đầu, bạn được phép xoay máy đo. Một phép nhân ma trận sẽ cho biết nên xoay về đâu.

Lớp này dành cho sinh viên năm ba đã học đại số tuyến tính, ma trận phức, xác suất và đạo hàm, tích phân một biến. Nếu ký hiệu ket còn lạ, bạn có thể bắt đầu từ [48 bài máy tính lượng tử cho học sinh lớp 12](https://www.phamduytung.com/courses/may-tinh-luong-tu/). Mỗi bài ở đây giải một câu hỏi trên giấy, vẽ kết quả, rồi chạy một đoạn Python kiểm tra. Trừ phần thống kê số lượt, các mô phỏng dùng cổng và phép đo lý tưởng.

Bắt đầu với quy ước nhỏ. Dấu † nghĩa là chuyển vị rồi lấy liên hợp phức. Trong các phép tính tay, nhãn hai qubit được đọc từ trái sang phải. Ở các bài dùng Qiskit, dây số 0 mang trọng số thấp nhất khi in chuỗi bit. Góc trong code luôn được đưa về radian trước khi gọi hàm lượng giác.


[Tải riêng notebook có mã và kết quả của cả 18 thí nghiệm](thi-nghiem-luong-tu.ipynb). Bạn có thể chạy từng ô độc lập bằng Jupyter.


## Trạng thái và phép đo

Dấu của một biên độ phức có thể làm đổi đầu dò nào sẽ sáng?

- [Bài 01 · Đổi thước đo, dấu i đi đâu?](bai-01-bien-do-va-doi-co-so.md)
- [Bài 02 · Máy có thể chỉ một số khác cả hai trị riêng không?](bai-02-pho-va-phep-chieu.md)

## Hàm sóng và phương trình Schrödinger

Chuyển từ một cột số sang một hàm của vị trí, rồi xem hai mức năng lượng tạo ra một nhịp dao động.

- [Bài 03 · Vì sao mật độ có thể lớn hơn một?](bai-03-mat-do-ham-song.md)
- [Bài 04 · Kéo giếng thế rộng gấp đôi có làm năng lượng giảm một nửa?](bai-04-hamiltonian-va-gieng-the.md)
- [Bài 05 · Hai mức năng lượng đứng yên, vì sao mật độ lại chuyển động?](bai-05-tien-hoa-schrodinger.md)

## Từ spin đến cổng quay

Xoay bộ tách chùm, cho qubit tiến hóa và so kết quả lý tưởng với một đợt 400 phép đo.

- [Bài 06 · Vì sao xoay máy đo 60° lại phải tính cos của 30°?](bai-06-spin-va-nua-goc.md)
- [Bài 07 · Một hiệu năng lượng tạo ra cổng quay như thế nào?](bai-07-tu-truong-va-cong-quay.md)
- [Bài 08 · Bốn trăm phép đo có bắt buộc cho đúng ba trăm số 0?](bai-08-pennylane-do-spin.md)

## Hệ ghép, rối và giới hạn CHSH

Hai sổ đo riêng rẽ cùng trông ngẫu nhiên. Ghép chúng lại, những tương quan nào mới xuất hiện?

- [Bài 09 · Theo dõi riêng một nửa cặp Bell thì mất thông tin gì?](bai-09-vet-rien-phan.md)
- [Bài 10 · Hai phong bì có thể hẹn trước với nhau đến mức nào?](bai-10-bell-gioi-han-co-dien.md)
- [Bài 11 · Bốn cặp hướng đo nào cho giá trị CHSH bằng 2√2?](bai-11-thi-nghiem-chsh.md)

## Từ mạch thuận nghịch đến Deutsch–Jozsa

Lắp một oracle hai CNOT và lần theo dấu trừ từ dây phụ đến quyết định cuối.

- [Bài 12 · Làm thế nào biến một hàm nhiều-vào-một thành cổng lượng tử?](bai-12-oracle-thuan-nghich.md)
- [Bài 13 · Vì sao đổi bit phụ lại làm nhánh dữ liệu đổi dấu?](bai-13-phase-kickback.md)
- [Bài 14 · Một truy vấn đủ phân biệt hàm hằng với hàm cân bằng bằng cách nào?](bai-14-deutsch-jozsa.md)

## Grover, biến đổi Fourier và Shor

Chọn điểm dừng cho tìm kiếm, đọc một pha bằng Fourier rồi dùng số học kiểm tra kết quả phân tích 21.

- [Bài 15 · Với 16 ngăn, nên dừng Grover ở vòng nào?](bai-15-grover-muoi-sau-o.md)
- [Bài 16 · Một nhịp 3/8 vòng hiện thành số 3 như thế nào?](bai-16-fourier-va-uoc-luong-pha.md)
- [Bài 17 · Vì sao bài tìm bậc của 2 theo mô-đun 21 sinh ra sáu pha?](bai-17-shor-pho-cua-phep-nhan.md)
- [Bài 18 · Máy trả về 11, làm sao lấy được hai ước của 21?](bai-18-shor-hau-xu-ly.md)

## Đọc sách song song với bài tập

Nếu đang kẹt ở một phép tính, bạn có thể mở thẳng mục tương ứng. Số trang ghi “PDF” được đếm từ trang đầu của tệp, gồm cả bìa.

| Khi học bài | Sách và phần nên mở | Việc thử trên giấy |
|---|---|---|
| 01 · Đổi cơ sở | Leonard S. Woody III, *Essential Mathematics for Quantum Computing*, mục “Conjugate transpose of a matrix”, trang PDF 139 | Tính tích vô hướng của một vectơ phức với chính nó theo hai cách. |
| 04 · Giếng thế | Shivakumar Hunagund, chương 4 trong *Principles and Applications of Quantum Computing Using Essential Math*, trang PDF 81 | Tính mật độ còn lại khi đi từ mép giếng ra ngoài một độ dài suy giảm. |
| 06 · Đo spin | Shinil Cho, *Quantum Computation and Quantum Information Simulation using Python*, mục 1.3.2–1.3.5 | Theo dõi riêng số hạt đến từng bộ tách và số hạt đi hết hai cửa. |
| 09 và 18 · Trạng thái con và tìm bậc | Stefano Olivares, *A Student’s Guide to Quantum Computing*, mục 2.6–2.8 và 5.3.1–5.3.3 | Tính độ tinh khiết của nửa cặp Bell. Đến bài 18, thử ghép hai mẫu số rồi kiểm tra bậc. |
| 12 · Hai bit tương quan | Seth Lloyd, *Programming the Universe*, chương 4, trang in 82 | Liệt kê các nhãn còn có thể xuất hiện sau khi chạy CNOT một lần và hai lần. |
| 12 · Oracle thuận nghịch | Sudeep Satheesan và Sri Mounica Kalidasu, *Quantum Computing Concepts*, chương 4, trang PDF 180 | Dựng bảng tám hàng của cổng Toffoli với cả hai trạng thái đầu của dây đích. |
| 14 · Phân biệt hai loại hàm | R. Anitha và cộng sự, chương 4 trong *Frontiers in Quantum Computing: New Research*, trang PDF 85–86 | Viết cả bốn hàm một bit và dự đoán kết quả phép đo cuối cho từng hàm. |
| 15 · Grover | Noson S. Yanofsky và Mirco A. Mannucci, *Quantum Computing for Computer Scientists*, mục 6.4, trang PDF 215–217 | Tính điểm thứ hai trên đồ thị bằng trung bình của 16 biên độ. |

## Tham khảo

- Griffiths & Schroeter, *Introduction to Quantum Mechanics*, ấn bản 3, chương 3. [Mục lục của Cambridge](https://assets.cambridge.org/97811071/89638/frontmatter/9781107189638_frontmatter.pdf).
- Nielsen & Chuang, *Quantum Computation and Quantum Information*, bản kỷ niệm 10 năm, chương 5. [Mục lục của Cambridge](https://assets.cambridge.org/97811070/02173/toc/9781107002173_toc.pdf).
- [IBM Quantum Learning · Ước lượng pha và phân tích thừa số](https://eu-de.quantum.cloud.ibm.com/learning/en/courses/fundamentals-of-quantum-algorithms/phase-estimation-and-factoring/introduction).
