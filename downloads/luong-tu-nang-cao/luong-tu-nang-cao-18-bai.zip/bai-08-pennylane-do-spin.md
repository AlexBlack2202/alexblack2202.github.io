# Bài 08 · Bốn trăm phép đo có bắt buộc cho đúng ba trăm số 0?

## Đặt vấn đề

Bạn cùng bàn dự đoán 300 số 0 sau 400 lần chạy mạch ở góc 60°. Mình thử đổi hạt giống ngẫu nhiên và thấy số đếm có thể đổi. Phải lệch bao xa mới đáng quay lại kiểm tra cổng?

Mạch có một qubit bắt đầu ở 0. Cổng $R_y(\theta)$ biến nó thành $(\cos(\theta/2),\sin(\theta/2))^T$. Đầu đọc Z cho số 0 với xác suất $p=3/4$ khi $\theta=\pi/3$. Bài 06 giữ nguồn cố định rồi xoay máy. Ở đây mình xoay nguồn rồi giữ máy; hai cách cho cùng xác suất trong ví dụ này vì cos bình phương là hàm chẵn. Phân biệt hai thao tác sẽ quan trọng khi bạn ghép nhiều phép quay khác trục.

## Hai câu hỏi cho cùng một mạch

Ở chế độ xác suất lý tưởng, đọc trực tiếp hai môđun bình phương. Ở chế độ lấy mẫu, đặt $I_j=1$ nếu lượt $j$ ra 0, còn lại bằng 0. Số đếm là $K=\sum_j I_j$. Với $N$ lượt độc lập và nguồn ổn định, cộng phương sai của các biến chỉ báo cho ta
$$
\mathbb E K=Np,\qquad \operatorname{sd}(K)=\sqrt{Np(1-p)},\qquad \operatorname{sd}(K/N)=\sqrt{p(1-p)/N}.
$$
Thay số được độ lệch chuẩn khoảng 8,66 lượt, hay 2,17 điểm phần trăm. Một bản ghi **giả định** có 291 số 0 chỉ lệch khoảng 1,04 độ lệch chuẩn. Gọi đó là bằng chứng mạch hỏng sẽ hơi vội. Trong notebook, bạn chạy cả phép đọc xác suất và phép đọc mẫu từ một máy mô phỏng cục bộ. Đổi riêng góc rồi thử lại trước khi thay số lượt.

![Phân bố số đếm trong 400 lượt](hinh/hinh-08.webp)

*Các cột là phân bố nhị thức lý thuyết của K. Vạch tại 300 đánh dấu kỳ vọng trên nhiều đợt chạy độc lập.*

## Kiểm chứng bằng Python

Đổi seed để có một sổ đo khác. Giá trị lý tưởng phải giữ nguyên khi chỉ thay seed.

```python
import numpy as np
import pennylane as qml
dev = qml.device("default.qubit", wires=1, seed=73)

@qml.qnode(dev)
def probabilities(angle):
    qml.RY(angle, wires=0)
    return qml.probs(wires=[0])

@qml.set_shots(shots=400)
@qml.qnode(dev)
def counts(angle):
    qml.RY(angle, wires=0)
    return qml.counts(wires=[0])

print("Lý tưởng:", probabilities(np.pi/3))
print("Một đợt lấy mẫu:", counts(np.pi/3))
assert np.allclose(probabilities(np.pi/3), [0.75, 0.25])
```

Kết quả của lần chạy trong sổ thực hành:

```text
Lý tưởng: [0.75 0.25]
Một đợt lấy mẫu: {np.str_('0'): np.int64(302), np.str_('1'): np.int64(98)}
```

## Tự thử

Muốn giảm độ lệch chuẩn của tỷ lệ xuống một nửa ở cùng góc, cần bao nhiêu lượt?

**Lời giải.** Tăng từ 400 lên 1.600. Độ lệch chuẩn của tỷ lệ tỉ lệ nghịch với căn bậc hai của số lượt. Phép tăng này xử lý dao động lấy mẫu. Nếu góc quay thực bị lệch một lượng cố định, lấy nhiều mẫu hơn sẽ làm sai lệch hệ thống hiện rõ hơn.

## Tham khảo

- Griffiths & Schroeter, *Introduction to Quantum Mechanics*, ấn bản 3, chương 4. [Mục lục của Cambridge](https://assets.cambridge.org/97811071/89638/frontmatter/9781107189638_frontmatter.pdf).

Ôn từ lớp nhập môn: [Tung 10 lần, vì sao chưa chắc có đúng 5 mặt ngửa?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-03-tung-dong-xu-va-tan-suat-thuc-nghiem/) · [Đọc bảng số đếm thế nào khi có lượt máy dò im?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-06-doc-bang-so-dem-photon/).

[Về mục lục](muc-luc.md)
