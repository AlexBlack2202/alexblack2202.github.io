# Bài 10 · Hai phong bì có thể hẹn trước với nhau đến mức nào?

## Đặt vấn đề

Trước khi ra hai phòng, An và Bình được phép bàn nhau tùy thích. Sang phòng rồi, mỗi người nhận ngẫu nhiên một trong hai câu hỏi và phải trả lời bằng +1 hoặc −1. Nếu họ viết trước đáp án lên hai thẻ, liệu có cách sắp thẻ để bốn tương quan đều thuận lợi cho cùng một tổng điểm?

Hãy thử một bộ thẻ: An ghi $(+1,-1)$, Bình ghi $(+1,-1)$. Ba tích đầu theo thứ tự $A_0B_0,A_0B_1,A_1B_0$ là $1,-1,-1$; tích cuối $A_1B_1=1$. Lấy ba tích đầu trừ tích cuối được −2. Thử bộ toàn dấu cộng thì được +2. Có cách kiếm 4 điểm không? Nhóm lại theo đáp án của An:
$$
s=A_0(B_0+B_1)+A_1(B_0-B_1).
$$
Nếu hai đáp án của Bình giống nhau, chỉ ngoặc đầu khác 0. Nếu chúng khác nhau, chỉ ngoặc sau khác 0. Ngoặc khác 0 có độ lớn 2. Mỗi bộ thẻ vì vậy chỉ được −2 hoặc +2. Các bên có thể dùng chung đồng xu để chọn ngẫu nhiên bộ thẻ; trung bình có trọng số của các giá trị ấy vẫn nằm trong đoạn $[-2,2]$. Ngẫu nhiên cục bộ cũng có thể gộp vào biến chỉ định bộ thẻ.

![Điểm CHSH của 16 bộ thẻ](hinh/hinh-10.webp)

*Mười sáu cách điền bốn dấu chia thành hai nhóm bằng nhau. Đổi xác suất chọn từng thẻ chỉ chuyển trọng lượng giữa hai cột.*

Trong thí nghiệm thật, mỗi cặp chỉ được hỏi một cặp câu hỏi. Ta ước lượng riêng bốn trung bình $E_{ij}$ từ bốn nhóm lượt khác nhau, rồi tính $S=E_{00}+E_{01}+E_{10}-E_{11}$. Việc áp bất đẳng thức cho tổng ấy dựa vào hai giả thiết: lựa chọn câu hỏi độc lập với biến ẩn do nguồn mang tới, và kết quả ở mỗi bên chỉ phụ thuộc lựa chọn tại chỗ cùng biến ẩn. Nếu chọn lọc các lượt được giữ theo câu hỏi và kết quả, bốn nhóm có thể không còn cùng một quần thể.

## Kiểm chứng bằng Python

Vòng lặp duyệt đủ 16 chiến lược xác định. Bạn có thể tự gán trọng số cho chúng và thử đẩy trung bình vượt 2.

```python
from collections import Counter
from itertools import product
scores = Counter(a*b + a*d + c*b - c*d for a,c,b,d in product((-1,1), repeat=4))
print(sorted(scores.items()))
assert scores == {-2: 8, 2: 8}
```

Kết quả của lần chạy trong sổ thực hành:

```text
[(-2, 8), (2, 8)]
```

## Tự thử

Nếu luôn cho Bình xem câu hỏi của An trước khi đáp, bước nào trong chứng minh mất hiệu lực?

**Lời giải.** Lúc ấy một ký hiệu $B_0$ không còn dùng chung được cho cả trường hợp An nhận câu 0 và câu 1. Ta không thể gom hai tích về cùng ngoặc như trên. Đó là lý do cách bố trí thí nghiệm quan trọng ngang với phép cộng bốn con số.

## Tham khảo

- Nielsen & Chuang, *Quantum Computation and Quantum Information*, bản kỷ niệm 10 năm, chương 2. [Mục lục của Cambridge](https://assets.cambridge.org/97811070/02173/toc/9781107002173_toc.pdf).
- [IBM Quantum Learning · Trò chơi CHSH](https://eu-de.quantum.cloud.ibm.com/learning/en/courses/basics-of-quantum-information/entanglement-in-action/chsh-game).

Ôn từ lớp nhập môn: [Hai phong bì giống nhau giải thích được phần nào của cặp Bell?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-29-tuong-quan-cua-cap-bell/) · [Vì sao rối lượng tử không truyền được tin nhắn từ xa?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-30-roi-luong-tu-va-truyen-tin/).

[Về mục lục](muc-luc.md)
