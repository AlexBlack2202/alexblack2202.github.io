# Bài 05 · Hai mức năng lượng đứng yên, vì sao mật độ lại chuyển động?

## Đặt vấn đề

Mình đặt hai kim đồng hồ chồng lên nhau. Nếu chúng quay cùng tốc độ, góc giữa chúng cố định. Nếu một kim quay nhanh hơn, lúc thì hai kim chỉ cùng phía, lúc lại đối nhau. Trong giếng của bài trước, hai trạng thái riêng năng lượng cũng tích lũy pha với hai tốc độ khác nhau. Mình muốn biết một đầu dò đặt gần $x=L/4$ sẽ thấy gì.

Chuẩn bị $(\phi_1+\phi_2)/\sqrt2$ lúc $t=0$. Phương trình phụ thuộc thời gian là $i\hbar\,\partial_t\psi=H\psi$. Với Hamiltonian không đổi theo thời gian, thay riêng từng nghiệm $H\phi_n=E_n\phi_n$ vào phương trình, hệ số của nó phải thỏa $i\hbar c'_n=E_nc_n$. Vì thế $c_n(t)=c_n(0)e^{-iE_nt/\hbar}$. Pha tính bằng radian; $E_nt/\hbar$ không có đơn vị.
$$
|\psi(x,t)|^2=\frac{\phi_1^2+\phi_2^2}{2}+\phi_1\phi_2\cos[(E_2-E_1)t/\hbar].
$$
Hai hàm riêng trong bài này được chọn thực. Hạng cuối đến từ phép nhân chéo khi lấy môđun bình phương. Tại $x=L/4$, ta có $\phi_1=1/\sqrt L$ và $\phi_2=\sqrt{2/L}$. Mật độ tại đó dao động giữa $(1{,}5-\sqrt2)/L$ và $(1{,}5+\sqrt2)/L$. Một điểm có xác suất bằng 0 với phân bố liên tục. Để so với đầu dò thật, phải tích phân mật độ trên bề rộng của đầu dò.

![Dao động mật độ tại một phần tư giếng](hinh/hinh-05.webp)

*Trục ngang đếm phần của chu kỳ tương đối $T=2\pi\hbar/(E_2-E_1)$. Ở nửa chu kỳ, hạng giao thoa đổi dấu.*

## Kiểm chứng bằng Python

Mình bỏ pha chung của mức thứ nhất khi tính. Tổng diện tích vẫn là một ở cả bốn thời điểm.

```python
import numpy as np
x = np.linspace(0, 1, 1001)  # tính độ dài theo L
u, v = np.sqrt(2)*np.sin(np.pi*x), np.sqrt(2)*np.sin(2*np.pi*x)
for t in [0, 0.25, 0.5, 1]:  # thời gian theo T
    rho = np.abs((u + v*np.exp(-2j*np.pi*t))/np.sqrt(2))**2
    print(f"t/T = {t:g}, Lρ(L/4) = {rho[250]:.6f}")
    assert np.isclose(np.trapezoid(rho, x), 1)
```

Kết quả của lần chạy trong sổ thực hành:

```text
t/T = 0, Lρ(L/4) = 2.914214
t/T = 0.25, Lρ(L/4) = 1.500000
t/T = 0.5, Lρ(L/4) = 0.085786
t/T = 1, Lρ(L/4) = 2.914214
```

## Tự thử

Nếu chỉ đo năng lượng đúng lúc mật độ ở $L/4$ thấp nhất, xác suất nhận $E_1$ còn bao nhiêu?

**Lời giải.** Vẫn là $1/2$. Phép đo năng lượng chiếu vào $\phi_1$, bình phương môđun hệ số của nó giữ nguyên. Khi tích phân mật độ trên toàn giếng, tích phân của $\phi_1\phi_2$ cũng bằng 0 nhờ trực giao. Vì vậy một vùng có thể tối đi mà tổng xác suất vẫn bằng một.

## Tham khảo

- Griffiths & Schroeter, *Introduction to Quantum Mechanics*, ấn bản 3, chương 2. [Mục lục của Cambridge](https://assets.cambridge.org/97811071/89638/frontmatter/9781107189638_frontmatter.pdf).
- [OpenStax · Nghiệm cho hạt trong giếng thế](https://openstax.org/books/university-physics-volume-3/pages/7-4-the-quantum-particle-in-a-box).

Ôn từ lớp nhập môn: [Đổi dấu riêng một biên độ thì điều gì thay đổi?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-15-doi-pha-tuong-doi/) · [Kéo dài một nhánh làm số đếm đổi ra sao?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-17-doi-chieu-dai-duong-di-va-pha/).

[Về mục lục](muc-luc.md)
