# Bài 03 · Vì sao mật độ có thể lớn hơn một?

## Đặt vấn đề

Màn hình có một vệt sáng dài nửa micromét. Bên cạnh nó, chương trình ghi số 2. Một bạn nhìn thấy và báo “xác suất 200%”. Mình kéo thanh đổi đơn vị từ micromét sang mét, con số còn lớn hơn. Thứ vừa đổi là gì?

Xét một mô hình ở một thời điểm: mật độ vị trí đều trên khoảng dài $L=0{,}5\,\mu\mathrm m$ và bằng 0 ở ngoài. Chia khoảng ấy thành năm ô. Máy lý tưởng tìm thấy hạt ở mỗi ô với xác suất $1/5$. Mỗi ô rộng $0{,}1\,\mu\mathrm m$. Lấy xác suất chia bề rộng, ta được $2\,\mu\mathrm m^{-1}$. Nếu thu bề rộng ô còn một nửa, xác suất trong ô giảm một nửa và thương số vẫn bằng 2.

## Diện tích mà máy dò thực sự đếm

$$
\rho(x)=|\psi(x)|^2,\quad P(a\le x\le b)=\int_a^b\rho(x)\,dx,\quad \int_{-\infty}^{\infty}\rho(x)\,dx=1.
$$
Trong một chiều $\rho$ có đơn vị nghịch đảo chiều dài, còn $\psi$ có đơn vị nghịch đảo căn chiều dài. Với detector từ 0,1 đến 0,3 micromét, diện tích là $2(0{,}3-0{,}1)=0{,}4$. Đổi mọi số sang mét thì chiều cao thành $2\times10^6\,\mathrm m^{-1}$, bề rộng thành $2\times10^{-7}\,\mathrm m$ và tích vẫn bằng 0,4. Mô hình xấp xỉ một vùng phân bố phẳng; hai cạnh gắt trong hình chỉ phục vụ bài toán xác suất tại một thời điểm.

![Hai ô máy dò trong năm ô vị trí](hinh/hinh-03.webp)

*Diện tích tô đậm chiếm hai trong năm ô bằng nhau. Trong 1.000 lần chuẩn bị độc lập, số đếm kỳ vọng trong vùng đậm là 400.*

## Kiểm chứng bằng Python

Thử chia thành mười ô, giữ nguyên vùng vật lý từ 0,1 đến 0,3 µm. Khi đó phải cộng bốn ô nhỏ.

```python
import numpy as np
edges = np.linspace(0, 0.5, 6)  # micromét
p = 2 * np.diff(edges)
print("Từng ô:", p, "  vùng từ 0,1 tới 0,3:", p[1:3].sum())
assert np.isclose(p.sum(), 1)
```

Kết quả của lần chạy trong sổ thực hành:

```text
Từng ô: [0.2 0.2 0.2 0.2 0.2]   vùng từ 0,1 tới 0,3: 0.4000000000000001
```

## Tự thử

Hai hàm sóng có cùng chiều cao mật độ ở mọi điểm vào lúc này. Liệu mình đã biết chắc chúng sẽ cho cùng mật độ ở mọi thời điểm sau?

**Lời giải.** Chưa. Có thể nhân $\psi(x)$ với $e^{ikx}$, trong đó $k$ có đơn vị nghịch đảo chiều dài. Môđun tại từng điểm giữ nguyên, nhưng pha thay đổi theo vị trí. Toán tử động năng ở bài sau lấy đạo hàm theo $x$ nên nhạy với thay đổi ấy. Sổ vị trí ở một thời điểm chưa xác định toàn bộ trạng thái.

## Tham khảo

- Griffiths & Schroeter, *Introduction to Quantum Mechanics*, ấn bản 3, chương 1. [Mục lục của Cambridge](https://assets.cambridge.org/97811071/89638/frontmatter/9781107189638_frontmatter.pdf).
- [Cambridge · Đọc trích chương về hàm sóng](https://assets.cambridge.org/97811071/89638/excerpt/9781107189638_excerpt.pdf).

Ôn từ lớp nhập môn: [Qua kính chia sáng, một photon cho mấy tiếng kêu?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-04-photon-qua-kinh-chia-sang/) · [Đọc bảng số đếm thế nào khi có lượt máy dò im?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-06-doc-bang-so-dem-photon/).

[Về mục lục](muc-luc.md)
