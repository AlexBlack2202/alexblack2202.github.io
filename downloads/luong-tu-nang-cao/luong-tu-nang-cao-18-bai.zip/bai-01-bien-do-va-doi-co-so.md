# Bài 01 · Đổi thước đo, dấu i đi đâu?

## Đặt vấn đề

Mình bịt nhãn hai hộp. Hộp thứ nhất phát qubit có cột biên độ $(1,i)^T/\sqrt2$, hộp thứ hai phát $(1,-i)^T/\sqrt2$. Bạn được chọn cách đặt máy đo. Nếu đặt máy ở chế độ mặc định, cứ khoảng một nửa số lượt ghi 0. Có đáng ngồi đếm thêm một triệu lần?

Trong cơ sở mặc định $Z$, bình phương môđun của từng hàng đều bằng $1/2$ ở cả hai hộp. Cuốn sổ của bạn thiếu dấu của phần ảo. Muốn biết dấu đó có tồn tại trong phép đo nào, mình dùng ngay trạng thái của hộp thứ nhất làm hướng đầu tiên của một hệ trục mới. Gọi hướng ấy là $u$, hướng còn lại là $v$, lần lượt bằng hai cột ở đầu bài.

## Một phép nhân ma trận có liên hợp

Với hộp thứ nhất, hình chiếu lên $u$ là $(1+(-i)i)/2=1$. Hình chiếu lên $v$ là $(1+i\,i)/2=0$. Chính dấu liên hợp trong tích vô hướng làm hai hướng này vuông góc. Nếu chỉ chuyển vị, bạn sẽ gán nhầm kết quả chắc chắn cho đầu dò còn lại.

Viết hai hướng thành các cột của ma trận $B=[u\ v]$. Máy đo theo cơ sở đó đọc tọa độ mới của trạng thái chuẩn hóa $\psi$. Quy tắc Born cho xác suất không có đơn vị:
$$
c=B^\dagger\psi,\qquad P(j)=|c_j|^2,\qquad B^\dagger B=I.
$$

![Hai hộp qubit dưới hai cơ sở đo](hinh/hinh-01.webp)

*Trong hình, hai cột màu của đầu dò Z đều cao một nửa. Đến cơ sở Y, toàn bộ xác suất của mỗi hộp chuyển về một đầu riêng.*

Bạn có thể chế phép đo này bằng cách đặt cổng $B^\dagger$ trước máy đọc Z. Hai cách nói “đổi cơ sở để tính” và “thêm cổng trước khi đo” cho cùng thống kê qua đẳng thức trên. Một cách là đổi tọa độ trên giấy, cách kia là tác động lên qubit trong phòng thí nghiệm.

## Một vectơ có thể vuông góc với chính nó không?

Hãy tạm nghe lời một chương trình dùng phép chuyển vị thường. Với hộp thứ nhất, $u=(1,i)^T/\sqrt{2}$, nó tính $u^Tu=(1+i^2)/2=0$. Vậy đầu dò được đặt đúng theo trạng thái mình vừa chuẩn bị lại chẳng bao giờ sáng! Đổi sang tích vô hướng phức, ta được $u^\dagger u=(1+(-i)i)/2=1$. Còn khi chiếu hộp thứ hai $v$ lên chính đầu dò ấy, hai hạng mới thật sự triệt tiêu. Đây là một phép thử nhỏ cho mã mô phỏng. Trong NumPy, bạn có thể gõ `np.vdot(u, u)` và `np.dot(u, u)` để thấy đúng chỗ hai phép tính rẽ nhau.

## Kiểm chứng bằng Python

Đổi dấu ở hàng thứ hai rồi dự đoán cột xác suất nào sẽ hoán đổi trước khi chạy.

```python
import numpy as np
B = np.array([[1, 1], [1j, -1j]]) / np.sqrt(2)
for psi in B.T:
    print("Z =", np.abs(psi)**2, "  Y =", np.round(np.abs(B.conj().T @ psi)**2, 8))
assert np.allclose(B.conj().T @ B, np.eye(2))
```

Kết quả của lần chạy trong sổ thực hành:

```text
Z = [0.5 0.5]   Y = [1. 0.]
Z = [0.5 0.5]   Y = [0. 1.]
```

## Tự thử

Nếu nhân cả cột của hộp thứ hai với $i$, kết luận có đổi không?

**Lời giải.** Khi ấy $B^\dagger(iv)=i(0,1)^T$. Bình phương môđun vẫn cho $(0,1)$. Phép thử tìm được pha tương đối giữa hai hàng, còn phép nhân chung cả cột giữ nguyên mọi xác suất.

## Tham khảo

- Leonard S. Woody III, *Essential Mathematics for Quantum Computing*, mục “Conjugate transpose of a matrix”, trang PDF 139.
- Griffiths & Schroeter, *Introduction to Quantum Mechanics*, ấn bản 3, chương 3. [Mục lục của Cambridge](https://assets.cambridge.org/97811071/89638/frontmatter/9781107189638_frontmatter.pdf).

Ôn từ lớp nhập môn: [Đổi dấu riêng một biên độ thì điều gì thay đổi?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-15-doi-pha-tuong-doi/) · [Đổi cơ sở đo là đổi câu hỏi nào?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-23-doi-co-so-do-qubit/).

[Về mục lục](muc-luc.md)
