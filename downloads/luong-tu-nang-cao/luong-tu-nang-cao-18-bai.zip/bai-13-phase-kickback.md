# Bài 13 · Vì sao đổi bit phụ lại làm nhánh dữ liệu đổi dấu?

## Đặt vấn đề

Mình nối cổng vào dây đèn. Trên sơ đồ, hai dây dữ liệu chỉ điều khiển. Thế mà tính đến cuối, một hàng biên độ dữ liệu mang dấu âm, còn dây đèn vẫn rút ra được ở đúng trạng thái ban đầu. Dấu trừ đi qua dây nào?

Thử bắt đầu từ một nhãn dữ liệu $x$ và phụ ở $|-\rangle=(|0\rangle-|1\rangle)/\sqrt2$. Nếu $f(x)=1$, oracle tráo hai thành phần của phụ. Cột $(1,-1)/\sqrt2$ thành $(-1,1)/\sqrt2$, tức hệ số −1 nhân nguyên cột. Nếu $f(x)=0$ thì hệ số là +1. Cho dữ liệu là tổng của nhiều nhãn rồi dùng tính tuyến tính:
$$
U_f\sum_x a_x|x\rangle|-\rangle
=\left(\sum_x(-1)^{f(x)}a_x|x\rangle\right)|-\rangle .
$$
Trạng thái phụ tách ra ngoài vì xuất hiện cùng một ket trong mọi nhánh. Thuật ngữ *phase kickback* gọi đúng hiệu ứng đại số này. Lấy bốn nhãn ngang biên độ, hàm chẵn lẻ ở bài trước: bảng mới theo thứ tự 00, 01, 10, 11 là $(1,-1,-1,1)/2$. Dấu chung của riêng một nhánh nay là pha tương đối khi so nhánh đó với các nhánh khác. Đo Z ngay sẽ vẫn thấy mỗi nhãn với xác suất 1/4.

![Bốn biên độ sau khi đổi pha](hinh/hinh-13.webp)

*Hai thanh dưới trục ứng với hai nhãn làm bit phụ bị lật. Trục dọc là biên độ thực; bình phương chúng sẽ xóa dấu trước khi ta kịp đọc.*

## Kiểm chứng bằng Python

Nhân bảng hai thanh ghi với vectơ của dây phụ giúp đọc lại bốn biên độ dữ liệu kèm dấu.

```python
import numpy as np
minus = np.array([1, -1])/np.sqrt(2)
joint = np.array([minus if x.bit_count()%2 == 0 else minus[::-1] for x in range(4)])/2
data = joint @ minus.conj()
print("Biên độ:", np.round(data, 3), "  xác suất:", np.round(data**2, 3))
assert np.allclose(joint, np.outer(data, minus))
```

Kết quả của lần chạy trong sổ thực hành:

```text
Biên độ: [ 0.5 -0.5 -0.5  0.5]   xác suất: [0.25 0.25 0.25 0.25]
```

## Tự thử

Nếu thay $|-\rangle$ bằng $|+\rangle$, hoặc dùng $|0\rangle$, kết quả khác nhau ở đâu?

**Lời giải.** Với $|+\rangle$, tráo hai hàng giữ nguyên toàn bộ cột nên mọi nhánh cùng nhận hệ số +1. Với $|0\rangle$, phụ kết thúc ở $|f(x)\rangle$. Nếu cả hai giá trị hàm có mặt, dữ liệu ghép với hai trạng thái phụ trực giao. Khi bỏ phụ đi, các nhánh thuộc hai nhóm không còn giao thoa với nhau như trong công thức trên.

## Tham khảo

- Nielsen & Chuang, *Quantum Computation and Quantum Information*, bản kỷ niệm 10 năm, chương 1 và 4. [Mục lục của Cambridge](https://assets.cambridge.org/97811070/02173/toc/9781107002173_toc.pdf).
- [IBM Quantum Learning · Thuật toán Deutsch–Jozsa](https://eu-de.quantum.cloud.ibm.com/learning/en/courses/fundamentals-of-quantum-algorithms/quantum-query-algorithms/deutsch-jozsa-algorithm).

Ôn từ lớp nhập môn: [Cổng Z đổi điều gì dù tỷ lệ 0/1 giữ nguyên?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-20-cong-luong-tu-pauli-z/) · [Đánh dấu ô đúng chỉ bằng cách đổi dấu ra sao?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-33-danh-dau-dap-an-bang-pha/).

[Về mục lục](muc-luc.md)
