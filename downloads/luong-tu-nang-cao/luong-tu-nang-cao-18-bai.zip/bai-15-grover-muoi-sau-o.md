# Bài 15 · Với 16 ngăn, nên dừng Grover ở vòng nào?

## Đặt vấn đề

Bạn đi tìm một chìa khóa trong 16 ngăn. Ở ví dụ bốn ngăn, một vòng Grover là trúng chắc. Thêm hai qubit, liệu có phải chỉ cần thêm một vòng? Mình sẽ giữ nguyên chính xác hai phép biến đổi cũ và theo dõi góc quay của trạng thái.

Gọi $|w\rangle$ là nhãn đúng duy nhất, $|b\rangle$ là tổng chuẩn hóa của 15 nhãn sai. Vì các ngăn sai bắt đầu đối xứng và được xử lý như nhau, trạng thái luôn nằm trên mặt phẳng sinh bởi hai ket này. Thành phần của trạng thái đều $|s\rangle$ theo $w$ là $1/4$, theo $b$ là $\sqrt{15}/4$. Đặt góc từ trục $b$ về phía $w$ là $\theta=\arcsin(1/4)\approx14{,}48^\circ$.

## Tại sao mỗi vòng cộng hai lần góc?

Oracle đổi dấu thành phần $w$, đưa hướng ở góc $\gamma$ về $-\gamma$. Phép khuếch tán $D=2|s\rangle\langle s|-I$ giữ thành phần dọc $s$ và đổi dấu thành phần vuông góc, tức phản xạ quanh đường ở góc $\theta$. Vì hai góc trước và sau đối xứng qua $\theta$, góc mới là $2\theta-(-\gamma)=2\theta+\gamma$. Bắt đầu ở $\gamma=\theta$, sau $k$ vòng:
$$
P_k(w)=\sin^2((2k+1)\theta).
$$
Các giá trị ở vòng 0, 1, 2, 3, 4 lần lượt xấp xỉ 0,063; 0,473; 0,908; 0,961; 0,582. Muốn đỉnh đầu tiên gần 90°, giải $k\simeq\pi/(4\theta)-1/2\simeq2{,}61$, rồi so hai số nguyên kề. Mình chọn ba lần gọi oracle. Chi thêm một lượt sau đó làm giảm mạnh xác suất trúng.

![Xác suất thành công của Grover](hinh/hinh-15.webp)

*Đỉnh đầu nằm ở vòng 3 và thấp hơn 1. Các điểm là số lần thực hiện nguyên. đường nối chỉ giúp bạn đọc thứ tự.*

Trong notebook, nhãn cần tìm là 1011. Mạch minh họa phải biết nhãn để **chế** oracle; phần phản xạ của thuật toán chỉ nhận khối có thể gọi. Với một bài toán thật, chi phí xây khối kiểm tra điều kiện có thể chi phối cả mạch. Tỷ lệ truy vấn tăng theo căn số ngăn khi có một đáp án không tự cho ta thời gian chạy thực tế.

## Tự tìm lại xác suất 0,473 của vòng đầu

Bạn có thể kiểm tra điểm thứ hai trên hình mà chưa cần tính góc. Trước khi đánh dấu, mỗi ngăn có biên độ $1/4$. Oracle đổi dấu đúng một ngăn. Cộng 16 biên độ rồi chia 16, trung bình mới là $(15/4-1/4)/16=7/32$. Phản xạ một biên độ $a$ qua mức trung bình $\bar a$ cho $2\bar a-a$. Ngăn đúng đi từ $-1/4$ lên $11/16$, còn mỗi ngăn sai từ $1/4$ về $3/16$.

Bình phương để chuyển về xác suất. Ngăn đúng nhận $121/256\approx0{,}473$, còn cả 15 ngăn sai chia nhau $135/256$. Hai phần cộng vừa đúng một. Phép thử này cũng giải thích dòng `2*psi.mean() - psi` trong mã. Thứ được đem lấy trung bình là biên độ **có dấu**. Nếu lấy trung bình xác suất, mọi ngăn vẫn bằng nhau ngay sau oracle và phép phản xạ chẳng khuếch đại được gì.

## Kiểm chứng bằng Python

Mỗi vòng kiểm tra hai phép tính độc lập, một bên cập nhật cả 16 biên độ, một bên chỉ cộng góc.

```python
import numpy as np
psi = np.ones(16)/4
w = int("1011", 2)
theta = np.arcsin(1/4)
for k in range(5):
    print(k, round(psi[w]**2, 6))
    assert np.isclose(psi[w]**2, np.sin((2*k+1)*theta)**2)
    psi[w] *= -1
    psi = 2*psi.mean() - psi
```

Kết quả của lần chạy trong sổ thực hành:

```text
0 0.0625
1 0.472656
2 0.908447
3 0.961319
4 0.581704
```

## Tự thử

Vẫn 16 ngăn nhưng có bốn đáp án. Nếu chỉ cần gặp một đáp án bất kỳ, phải đổi góc ban đầu ra sao?

**Lời giải.** Chuẩn hình chiếu của trạng thái đều lên nhóm đúng là $\sqrt{4/16}=1/2$. Góc là 30°. Một vòng đưa góc tới 90°, nên trong mô hình lý tưởng xác suất trúng nhóm đó bằng 1.

## Tham khảo

- Noson S. Yanofsky và Mirco A. Mannucci, *Quantum Computing for Computer Scientists*, mục 6.4, phần phản xạ qua trung bình, trang PDF 215–217.
- Nielsen & Chuang, *Quantum Computation and Quantum Information*, bản kỷ niệm 10 năm, chương 6. [Mục lục của Cambridge](https://assets.cambridge.org/97811070/02173/toc/9781107002173_toc.pdf).

Ôn từ lớp nhập môn: [Thực hành chạy Grover cho bốn ô, một ô đúng](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-35-thuc-hanh-grover-voi-bon-o/) · [Thêm một vòng Grover có thể làm giảm cơ hội trúng thế nào?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-36-chon-so-vong-lap-grover/).

[Về mục lục](muc-luc.md)
