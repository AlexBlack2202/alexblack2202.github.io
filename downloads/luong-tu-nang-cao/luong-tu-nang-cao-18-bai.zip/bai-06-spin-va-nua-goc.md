# Bài 06 · Vì sao xoay máy đo 60° lại phải tính cos của 30°?

## Đặt vấn đề

Một chùm nguyên tử spin hiệu dụng ½ đi qua bộ tách Stern–Gerlach. Mình giữ chùm đi vào kênh “lên theo z”, rồi đưa nó sang bộ tách thứ hai nghiêng 60°. Nếu bạn lấy hình chiếu của mũi tên cổ điển và bình phương, bạn được $\cos^2(60^\circ)=1/4$. Vậy tại sao dự đoán lượng tử cho kênh lên lại là 3/4?

Hãy viết đại lượng mà máy thứ hai đo. Với trục trong mặt phẳng $xz$, góc $\theta$ tính từ $+z$ về $+x$, toán tử spin là $S_\theta=(\hbar/2)(Z\cos\theta+X\sin\theta)$. Ở đây $Z=\operatorname{diag}(1,-1)$, còn $X$ tráo hai tọa độ. Mỗi số đọc là $+\hbar/2$ hoặc $-\hbar/2$, cùng đơn vị mômen động lượng. Chia ma trận cho $\hbar/2$ để tìm vectơ riêng ứng với kênh lên.
$$
\begin{pmatrix}\cos\theta&\sin\theta\\ \sin\theta&-\cos\theta\end{pmatrix}
\binom{\cos u}{\sin u}=\binom{\cos(\theta-u)}{\sin(\theta-u)}.
$$
Muốn đầu ra bằng chính cột đầu vào, ta chọn $u=\theta/2$. Góc trên không gian các cột thực chỉ bằng nửa góc cơ khí của máy. Chiếu trạng thái chuẩn bị $(1,0)^T$ lên cột vừa tìm rồi bình phương, ta có $P(+_\theta)=\cos^2(\theta/2)$. Ở 60°, biên độ là $\sqrt3/2$, nên trong 400 lượt độc lập kỳ vọng 300 lượt lên.

![Xác suất tách spin khi xoay máy](hinh/hinh-06.webp)

*Ở góc 90°, hai kết quả ngang nhau. Ở 180°, một trạng thái lên theo trục cũ trở thành xuống theo trục mới với xác suất một.*

## Nếu bịt một kênh ở giữa hai bộ tách

Giữ 400 hạt đều ở trạng thái lên theo z. Cho chúng qua bộ tách nghiêng 60°, chỉ giữ kênh lên và đo lại theo z. Ở lượt lọc đầu, số hạt được giữ có kỳ vọng 300. Mỗi hạt đã lọc nay ở trạng thái lên theo trục nghiêng. Xác suất riêng của nó đi ra kênh lên theo z là $\cos^2(30^\circ)=3/4$. Cứ 400 hạt ban đầu, số hạt đi trọn cả hai cửa có kỳ vọng $400(3/4)^2=225$. Nếu quên mất cửa lọc ở giữa mà chỉ so hướng z ban đầu với hướng z cuối, bạn sẽ đoán 400. Chính việc giữ lại một kết quả ở bộ tách giữa đã chuẩn bị lại trạng thái đi vào bộ tách cuối.

## Kiểm chứng bằng Python

Các vectơ riêng là các cột của ma trận trả về. Hàng đầu cho biên độ chiếu của spin lên theo z lên từng vectơ ấy.

```python
import numpy as np
a = np.deg2rad(60)
M = np.array([[np.cos(a), np.sin(a)], [np.sin(a), -np.cos(a)]])
e, v = np.linalg.eigh(M)
print("Kênh:", e, "  xác suất:", np.abs(v[0, :])**2)
assert np.isclose(abs(v[0, -1])**2, 0.75)
```

Kết quả của lần chạy trong sổ thực hành:

```text
Kênh: [-1.  1.]   xác suất: [0.25 0.75]
```

## Tự thử

Lấy kết quả lên là +1 và xuống là −1. Trung bình của số ghi ở 60° là bao nhiêu?

**Lời giải.** $0{,}75-0{,}25=0{,}5=\cos(60^\circ)$. Phép chiếu cổ điển theo cos xuất hiện ở **trung bình của số đọc đã chuẩn hóa**. Xác suất một đầu ra lại là $(1+\cos\theta)/2$.

## Tham khảo

- Shinil Cho, *Quantum Computation and Quantum Information Simulation using Python*, mục 1.3.2 và 1.3.5 về phép chiếu spin và đổi hệ trục quan sát.
- Griffiths & Schroeter, *Introduction to Quantum Mechanics*, ấn bản 3, chương 4. [Mục lục của Cambridge](https://assets.cambridge.org/97811071/89638/frontmatter/9781107189638_frontmatter.pdf).

Ôn từ lớp nhập môn: [Đổi cơ sở đo là đổi câu hỏi nào?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-23-doi-co-so-do-qubit/) · [Biên độ 3/5 cho xác suất bao nhiêu?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-09-tinh-xac-suat-tu-bien-do/).

[Về mục lục](muc-luc.md)
