# Bài 12 · Làm thế nào biến một hàm nhiều-vào-một thành cổng lượng tử?

## Đặt vấn đề

Hai công tắc bật đúng một chiếc thì đèn sáng. Nhìn đèn sáng, mình biết có một công tắc bật nhưng không thể khôi phục đó là chiếc nào. Bạn thử viết phép biến đổi “hai bit công tắc thành một bit đèn” bằng ma trận unita: hai cột ứng với 01 và 10 sẽ đổ vào cùng một đầu ra. Hai cột trực giao ban đầu đã mất tính trực giao.

Mẹo là để công tắc nguyên chỗ và thêm một bit đèn $y$. Với $f(x_1x_0)=x_1\oplus x_0$, đổi trạng thái đèn theo quy tắc sau, trong đó $\oplus$ là cộng theo mô-đun 2:
$$
U_f|x\rangle|y\rangle=|x\rangle|y\oplus f(x)\rangle.
$$
Chẳng hạn $x=10,y=0$ thành $10,1$; cùng $x$ mà $y=1$ thì thành $10,0$. Đèn lúc đầu có thể sáng sẵn. Gọi lại hai lần, $f(x)$ bị cộng hai lần nên luôn lấy lại $y$. Quy tắc hoán vị đủ tám nhãn khiến ma trận unita, dù riêng hàm $f$ có hai tiền ảnh cho mỗi giá trị.

![Bảng tác động của oracle lên dây đích](hinh/hinh-12.webp)

*Mỗi hàng cố định một cặp công tắc. Hai ô trong cùng hàng cho thấy phải kiểm tra cả hai giá trị ban đầu của đèn.*

Trong Qiskit, dùng hai CNOT có chung đích: lần đầu điều khiển bởi $x_0$, lần sau bởi $x_1$. Trong bài viết mình ghi $(x_1x_0,y)$; nếu gán dây 0 cho $x_0$, dây 1 cho $x_1$, dây 2 cho $y$, chuỗi ket khi in của Qiskit là $|y\,x_1x_0\rangle$. Ví dụ đầu vào $(10,0)$ là số nguyên 2, đầu ra $(10,1)$ là số 6. Notebook kiểm cả tám trường hợp để phát hiện đổi nhầm dây trước khi dùng chồng chập.

## Hai chiếc đèn cùng sáng có làm mất một bit?

Mình đặt bit đích ở 0 và chọn bit điều khiển bằng đồng xu công bằng. Qua một CNOT, hai đầu ra chỉ có thể là 00 hoặc 11. Che một đèn, chiếc còn lại sáng một nửa số lượt. Nhìn cả hai, bạn vẫn chỉ cần một bit để ghi lại kết quả vì hai đèn luôn giống nhau. Cho cặp ấy qua cùng CNOT lần nữa, 00 trở về 00 và 11 về 10. Đèn đích trở lại 0 ở cả hai nhánh. Seth Lloyd dùng kiểu đối chiếu này để giải thích thông tin có thể nằm trong tương quan giữa các bit.

Với hai công tắc của ví dụ chính, bạn còn có thể thay hàm chẵn lẻ bằng hàm AND. Dùng cổng Toffoli, hai công tắc làm điều khiển và bóng đèn làm đích. Với đầu vào 11, đèn tắt sẽ bật, còn đèn bật sẵn sẽ tắt. Ba đầu vào 00, 01, 10 đều giữ nguyên đèn. Nhờ giữ hai bit điều khiển, cả tám nhãn đầu ra vẫn khác nhau, dù nhìn riêng kết quả AND chỉ có hai khả năng.

## Kiểm chứng bằng Python

Số nguyên đánh chỉ mục cột đầu vào có dây đích ở bit trọng số 4. Dự đoán đầu ra cho cột số 6 trước khi chạy.

```python
import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Operator
oracle = QuantumCircuit(3)
oracle.cx(0, 2)
oracle.cx(1, 2)
U = Operator(oracle).data
for x in range(4):
    for y in (0, 1):
        j = 4*y + x
        k = int(np.argmax(np.abs(U[:, j])))
        assert k == 4*(y ^ (x.bit_count() % 2)) + x
        print(f"x={x:02b}, y={y} → y′={k//4}")
```

Kết quả của lần chạy trong sổ thực hành:

```text
x=00, y=0 → y′=0
x=00, y=1 → y′=1
x=01, y=0 → y′=1
x=01, y=1 → y′=0
x=10, y=0 → y′=1
x=10, y=1 → y′=0
x=11, y=0 → y′=0
x=11, y=1 → y′=1
```

## Tự thử

Nếu chỉ dùng một CNOT từ $x_1$ sang đèn, đầu vào nào phát hiện ngay lỗi?

**Lời giải.** Chọn $x=01,y=0$. Giá trị hàm đúng bằng 1 nhưng $x_1=0$ nên mạch thiếu cổng để đèn ở 0. Thử riêng $x=00$ hay $10$ sẽ bỏ sót lỗi.

## Tham khảo

- Seth Lloyd, *Programming the Universe*, chương 4, ví dụ CNOT và tương quan ở trang in 82 (trang PDF 100).
- Sudeep Satheesan và Sri Mounica Kalidasu, *Quantum Computing Concepts*, chương 4, phần về cổng Toffoli, trang PDF 180.
- Nielsen & Chuang, *Quantum Computation and Quantum Information*, bản kỷ niệm 10 năm, chương 1 và 4. [Mục lục của Cambridge](https://assets.cambridge.org/97811070/02173/toc/9781107002173_toc.pdf).
- [IBM Quantum Learning · Thuật toán Deutsch–Jozsa](https://eu-de.quantum.cloud.ibm.com/learning/en/courses/fundamentals-of-quantum-algorithms/quantum-query-algorithms/deutsch-jozsa-algorithm).

Ôn từ lớp nhập môn: [Ghép hai qubit độc lập thì nhân những số nào?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-26-tich-tensor-cua-hai-qubit/) · [CNOT lật qubit thứ hai trong điều kiện nào?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-27-cong-cnot-va-qubit-dieu-khien/).

[Về mục lục](muc-luc.md)
