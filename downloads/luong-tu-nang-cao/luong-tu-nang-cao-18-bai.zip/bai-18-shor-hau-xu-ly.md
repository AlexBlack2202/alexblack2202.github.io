# Bài 18 · Máy trả về 11, làm sao lấy được hai ước của 21?

## Đặt vấn đề

Màn hình hiện 001011. Đọc theo nhị phân là 11. Số 21 không chia hết cho 11. Nếu đang tìm ước, tại sao mình lại vui khi thấy kết quả này? Vì thanh ghi sáu bit báo một điểm trên thước chia 64 vạch. Việc đầu tiên là viết $11/64$.

Các hệ số của thuật toán Euclid tới từ $64=5\cdot11+9$, $11=1\cdot9+2$, $9=4\cdot2+1$, $2=2\cdot1$. Phân số liên tục là $[0;5,1,4,2]$. Dừng ở từng độ sâu cho các phân số hội tụ $0/1,1/5,1/6,5/29,11/64$. Đặt cạnh thước trên hình, $1/6$ lệch khỏi $11/64$ đúng $1/192$. Vì bậc của đơn vị mô-đun 21 nhỏ hơn 21, mình chỉ cần xét các mẫu dương nhỏ hơn 21 trong danh sách này.
$$
2^5\bmod21=11,\qquad 2^6\bmod21=1,\qquad
\gcd(2^{6/2}-1,21)=7,\quad\gcd(2^{6/2}+1,21)=3.
$$
Vì sao hai ƯCLN có cơ hội tách 21? $2^6-1$ chia hết cho 21 và bằng $(2^3-1)(2^3+1)=7\cdot9$. Tìm phần chung của từng ngoặc với 21 cho hai ước thực sự. Muốn xác nhận 6 là **bậc nhỏ nhất** sau khi biết nó đưa về 1, thử $6/2=3$ và $6/3=2$. Số dư 8 và 4 đều khác 1. Chỉ cần thử chia theo các thừa số nguyên tố vì mọi ước thực sự của 6 đều chia ít nhất một trong hai số vừa thử.

![Mẫu đo và các phân số hội tụ lân cận](hinh/hinh-18.webp)

*Các dấu trên trục là phân số, không phải số dư theo 21. Chọn mẫu số bằng phép kiểm tra mô-đun ở dòng trên thay vì chỉ nhìn dấu nào nằm gần nhất.*

## Khi nhãn đo đẹp mà vẫn không giúp đủ

Nếu ra 32, phân số rút gọn là $32/64=1/2$. Pha có thể đã bắt đầu là $3/6$. Sau khi rút gọn, mẫu số bị mất thừa số 3; $2^2\bmod21=4$ bác bỏ ứng viên 2. Nếu ra 0, mẫu số 1 cũng chẳng cho bậc. Có thể thu thêm mẫu rồi kiểm tra bội chung của những mẫu số thích hợp. Một chu kỳ chẵn chỉ sinh ước hữu ích khi bước lấy ƯCLN không trả cả hai ước hiển nhiên. Nếu bậc lẻ hoặc nửa bậc cho −1 theo mô-đun số cần phân tích, đổi cơ số là một lối ra.

$Q=64$ là cấu hình dạy học cho **mẫu cụ thể**. Trong phân tích Shor tổng quát thường chọn lũy thừa hai $Q\ge N^2$ với $N$ là số cần phân tích, để có đủ độ phân giải cho bước khôi phục phân số. Với 21, lũy thừa hai nhỏ nhất đạt ngưỡng là 512. Không thể dựa vào việc một nhãn ở cấu hình nhỏ thành công để cam kết mọi lượt sáu bit đều đủ chính xác.

## Hai lượt đo đều hụt có thể giúp nhau thế nào?

Giả sử hai lượt đo độc lập cho nhãn 21 và 32 trên lưới 64. Với lượt đầu, $21/64$ gần $1/3$ vì chênh đúng $1/192$. Lượt sau cho đúng $32/64=1/2$. Thử riêng hai mẫu số làm số mũ, ta được $2^3\bmod21=8$ và $2^2\bmod21=4$. Cả hai lần đều chưa quay về 1.

Nhưng hai pha có thể là các phân số rút gọn của cùng một bậc. Bội chung nhỏ nhất của 3 và 2 là 6. Thử lại, $2^6\bmod21=1$. Để biết 6 là bậc nhỏ nhất, chia 6 lần lượt cho hai thừa số nguyên tố 2 và 3. Đó đúng là hai số mũ mình vừa thử và đã bác bỏ. Như vậy, ghép hai lượt ở đây khôi phục được phần thông tin mà mỗi phân số riêng đã mất khi rút gọn. Với một mẫu đo rơi xa đỉnh, phép ghép có thể đề xuất sai ứng viên. Bước lũy thừa mô-đun là chỗ mình kiểm lại bằng số học.

## Kiểm chứng bằng Python

Dòng in đầu tiên có thể hiện 0 thay cho 0/1 vì Python rút gọn cách hiển thị. Thuật toán vẫn xét mẫu số 1.

```python
from fractions import Fraction
from math import gcd
a, b = 11, 64
h0, h1, k0, k1 = 0, 1, 1, 0
while b:
    q, rem = divmod(a, b)
    a, b = b, rem
    h0, h1 = h1, q*h1+h0
    k0, k1 = k1, q*k1+k0
    print(Fraction(h1, k1), "  dư:", pow(2, k1, 21))
    if k1 < 21 and pow(2, k1, 21) == 1:
        r = k1
        break
z = pow(2, r//2, 21)
print("Ước:", gcd(z-1, 21), gcd(z+1, 21))
assert r == 6
```

Kết quả của lần chạy trong sổ thực hành:

```text
0   dư: 2
1/5   dư: 11
1/6   dư: 1
Ước: 7 3
```

## Tự thử

Nếu một ứng viên 12 vượt phép thử $2^{12}\bmod21=1$, có nên đưa ngay vào bước tách?

**Lời giải.** Chia thử ứng viên cho 2 cho số mũ 6, vẫn dư 1. Nếu dùng thẳng 12 thì nửa ứng viên đã cho $2^6\equiv1$, dẫn đến các ƯCLN hiển nhiên 21 và 1. Một chu kỳ đúng và bậc nhỏ nhất có vai trò khác nhau. Trở lại chuỗi 001011: chỉ sau khi xác minh mẫu số và thử ƯCLN, mình mới có thể báo đáp án 3 và 7.

## Tham khảo

- Stefano Olivares, *A Student’s Guide to Quantum Computing*, mục 5.3.1–5.3.3, đặc biệt phần phân số liên tục và kiểm tra bậc ở trang in 84–85.
- Nielsen & Chuang, *Quantum Computation and Quantum Information*, bản kỷ niệm 10 năm, chương 5. [Mục lục của Cambridge](https://assets.cambridge.org/97811070/02173/toc/9781107002173_toc.pdf).
- [IBM Quantum Learning · Ước lượng pha và phân tích thừa số](https://eu-de.quantum.cloud.ibm.com/learning/en/courses/fundamentals-of-quantum-algorithms/phase-estimation-and-factoring/introduction).

Ôn từ lớp nhập môn: [Biết chu kỳ 4 thì tìm được ước của 15 thế nào?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-38-tim-uoc-tu-chu-ky-trong-thuat-toan-shor/) · [Khôi phục rồi kiểm tra chu kỳ ứng viên thế nào?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-42-khoi-phuc-va-kiem-tra-chu-ky/).

[Về mục lục](muc-luc.md)
