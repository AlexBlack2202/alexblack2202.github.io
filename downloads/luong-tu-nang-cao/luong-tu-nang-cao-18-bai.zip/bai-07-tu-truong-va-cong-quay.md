# Bài 07 · Một hiệu năng lượng tạo ra cổng quay như thế nào?

## Đặt vấn đề

Hai phòng bên cạnh nhau có hai đồng hồ chạy hơi lệch. Mình chụp riêng từng mặt đồng hồ thì chỉ thấy kim đang quay. Muốn đo độ lệch tốc độ, mình cần so chúng với nhau sau một khoảng chờ. Qubit cũng có một thí nghiệm như thế: chuẩn bị hai biên độ cùng dấu, cho tiến hóa rồi trộn lại.

Chọn quy ước Hamiltonian $H=\hbar\omega Z/2$, với $\omega>0$ tính bằng rad/s. Đây là mô hình hai mức của spin trong từ trường dọc trục đã chọn; dấu của $\omega$ ở một thiết bị cụ thể phụ thuộc quy ước trục và hệ số từ. Khởi tạo $|+\rangle=(|0\rangle+|1\rangle)/\sqrt2$. Sau thời gian $t$, hai thành phần nhận hệ số $e^{-i\omega t/2}$ và $e^{i\omega t/2}$. Bỏ pha chung đi, cột trở thành $(1,e^{i\omega t})^T/\sqrt2$.
$$
P(+_x)=\left|\frac{1+e^{i\omega t}}{2}\right|^2=\frac{1+\cos(\omega t)}2.
$$
Lấy $\omega=2\pi\times10^3$ rad/s và chờ $0{,}25$ ms. Góc tương đối là $\pi/2$ nên $P(+_x)=1/2$. Nếu chờ $0{,}5$ ms, hai biên độ ngược dấu; kênh cộng tối hẳn. Đo theo Z suốt thí nghiệm vẫn thấy hai tỷ lệ bằng nhau. Trên cầu Bloch, vectơ có tọa độ $(\cos\omega t,\sin\omega t,0)$. đây là vectơ kỳ vọng của ba ma trận Pauli. Hai biên độ trong cột trạng thái là tọa độ của một đối tượng khác.

![Tín hiệu theo thời gian ở hai đầu đọc](hinh/hinh-07.webp)

*Đường nằm ngang là phép đo Z. Chỉ máy đọc X trong hai cấu hình trên biến độ lệch pha thành độ tương phản theo thời gian.*

## Kiểm chứng bằng Python

Mình giữ đơn vị mili giây xuyên suốt vòng lặp. Nhầm sang giây sẽ làm mất ba bậc độ lớn.

```python
import numpy as np
plus = np.ones(2)/np.sqrt(2)
for t_ms in [0, 0.25, 0.5, 1]:
    angle = 2*np.pi*t_ms  # tần số 1 kHz
    psi = plus * np.exp(-0.5j*angle*np.array([1, -1]))
    print(f"{t_ms:g} ms: P(+x)={abs(plus @ psi)**2:.3f}, P(0z)={abs(psi[0])**2:.3f}")
```

Kết quả của lần chạy trong sổ thực hành:

```text
0 ms: P(+x)=1.000, P(0z)=0.500
0.25 ms: P(+x)=0.500, P(0z)=0.500
0.5 ms: P(+x)=0.000, P(0z)=0.500
1 ms: P(+x)=1.000, P(0z)=0.500
```

## Tự thử

Cộng cùng năng lượng $E_0$ vào hai mức làm thay đổi chu kỳ nào?

**Lời giải.** Hamiltonian mới bằng $H+E_0I$, kéo theo hệ số chung $e^{-iE_0t/\hbar}$. Hiệu năng lượng vẫn bằng $\hbar\omega$. Hai đường trong hình giữ nguyên và chu kỳ của tín hiệu X vẫn là 1 ms.

## Tham khảo

- Griffiths & Schroeter, *Introduction to Quantum Mechanics*, ấn bản 3, chương 4. [Mục lục của Cambridge](https://assets.cambridge.org/97811071/89638/frontmatter/9781107189638_frontmatter.pdf).

Ôn từ lớp nhập môn: [Cổng Z đổi điều gì dù tỷ lệ 0/1 giữ nguyên?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-20-cong-luong-tu-pauli-z/) · [Đổi dấu riêng một biên độ thì điều gì thay đổi?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-15-doi-pha-tuong-doi/).

[Về mục lục](muc-luc.md)
