# Bài 14 · Một truy vấn đủ phân biệt hàm hằng với hàm cân bằng bằng cách nào?

## Đặt vấn đề

Mình đưa bạn hộp nhận hai bit rồi trả về một bit. Có lời hứa: hoặc bốn giá trị đầu ra đều giống nhau, hoặc có đúng hai số 0 và hai số 1. Bạn thử 00, nhận 0. Bạn thử 01, cũng 0. Đã kết luận được chưa? Hai ô còn lại vẫn có thể là 0,0 hoặc 1,1.

Trên mạch lượng tử, khởi tạo hai dây dữ liệu ở $|00\rangle$, cho Hadamard trên mỗi dây để được bốn hệ số $1/2$. Dây phụ ở $|-\rangle$. Sau một truy vấn, hàm chẵn lẻ chẳng hạn để lại bảng $(1,-1,-1,1)/2$ trên dữ liệu. Hai Hadamard cuối làm gì với nhãn 00? Hàng đầu của $H\otimes H$ là $(1,1,1,1)/2$. Nhân hàng ấy với cột vừa tính, đầu 00 nhận tổng bằng 0. Nếu bốn dấu giống nhau, đầu ấy nhận +1 hoặc −1.
$$
a(0^n)=2^{-n}\sum_{x=0}^{2^n-1}(-1)^{f(x)},\qquad P(0^n)=|a(0^n)|^2 .
$$
Ở đây $n$ là số dây đầu vào. Phải có một thừa số $2^{-n/2}$ cho lúc chuẩn bị và một thừa số nữa khi chiếu về đầu ra toàn 0. Dưới lời hứa, một lần đo lý tưởng trả toàn 0 cho hàm hằng, và một nhãn khác cho hàm cân bằng. Ở ví dụ chẵn lẻ hai bit, nhãn khác ấy luôn là 11 vì hàng 11 của ma trận có đúng mẫu dấu $(+,-,-,+)/2$. Với hàm cân bằng tổng quát trên nhiều bit, xác suất có thể chia giữa nhiều nhãn khác 0.

![Đóng góp vào đầu ra toàn số 0](hinh/hinh-14.webp)

*Bốn thanh ở mỗi nhóm cộng thành biên độ của một đầu ra duy nhất là 00. Chỉ nhóm có bốn dấu đồng thuận vượt qua phép cộng mà còn nguyên độ lớn một.*

## Hộp được gọi mấy lần, bên trong tốn bao nhiêu cổng?

Với hai bit, một thuật toán cổ điển xác định cần ba truy vấn trong trường hợp xấu nhất để trả lời chắc chắn. Với $n$ bit, kẻ ra đề có thể giữ cho $2^{n-1}$ câu trả lời đầu giống nhau. Lượt kế phân định hai khả năng. Trái lại, nếu cho phép xác suất sai, thuật toán cổ điển có thể lấy vài mẫu ngẫu nhiên: với hàm cân bằng và $m$ đầu vào lấy độc lập có hoàn lại, xác suất thấy cùng một giá trị ở cả $m$ lượt là $2^{1-m}$. Vì vậy phát biểu về ưu thế phải nói rõ có yêu cầu đáp án chính xác hay không.

Trong notebook, oracle chẵn lẻ được lắp bằng hai CNOT. “Một truy vấn” tính một lần gọi khối đó; hai CNOT vẫn là chi phí thực của cách lắp khối trong ví dụ. Không thể từ hai cách đếm này suy ngay ra tỷ lệ thời gian chạy.

## Thu nhỏ hộp còn một công tắc

Một cách tự kiểm lời giải là quay về bài toán Deutsch với đúng một bit đầu vào. Chỉ có bốn bảng giá trị, viết theo thứ tự $f(0),f(1)$ là 00, 11, 01 và 10. Với bảng 01, hai biên độ dữ liệu ngay trước Hadamard cuối là $(1,-1)/\sqrt{2}$. Với bảng 10, chúng là $(-1,1)/\sqrt{2}$. Khác nhau đúng một dấu chung, nên hai bảng đều cho kết quả đo 1. Hai bảng hằng cùng cho kết quả đo 0. Bạn có thể ghi điều máy thật sự trả lời bằng một phép tính tay. Bit đo cuối bằng $f(0)\oplus f(1)$. Nó cho biết hai đầu ra có khác nhau hay không, còn hai giá trị riêng lẻ vẫn chưa xác định.

## Kiểm chứng bằng Python

Mạch chỉ đọc phân bố biên của hai dây đầu. So hai ô khác 0 ở hai lần chạy rồi tra nhãn nhị phân của chúng.

```python
import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector
for parity in (False, True):
    qc = QuantumCircuit(3)
    qc.x(2)
    qc.h([0, 1, 2])
    if parity:  # hàm hằng 0 dùng oracle đồng nhất
        qc.cx(0, 2)
        qc.cx(1, 2)
    qc.h([0, 1])
    p = Statevector.from_instruction(qc).probabilities(qargs=[0, 1])
    print("Chẵn lẻ" if parity else "Hằng 0", np.round(p, 5))
    assert np.isclose(p[3 if parity else 0], 1)
```

Kết quả của lần chạy trong sổ thực hành:

```text
Hằng 0 [1. 0. 0. 0.]
Chẵn lẻ [0. 0. 0. 1.]
```

## Tự thử

Bỏ lời hứa, dùng hàm có ba giá trị 0 và một giá trị 1. Xác suất thấy 00?

**Lời giải.** Biên độ là $(3-1)/4=1/2$, xác suất $1/4$. Nhận 00 lúc này chưa đủ để kết luận hàm hằng.

## Tham khảo

- R. Anitha và cộng sự, “Bernstein Vazirani and Deutsch Algorithm: Made Easy in Qiskit”, chương 4 trong *Frontiers in Quantum Computing: New Research*, phần so sánh các bảng hàm, trang PDF 85–86.
- Nielsen & Chuang, *Quantum Computation and Quantum Information*, bản kỷ niệm 10 năm, chương 1 và 4. [Mục lục của Cambridge](https://assets.cambridge.org/97811070/02173/toc/9781107002173_toc.pdf).
- [IBM Quantum Learning · Thuật toán Deutsch–Jozsa](https://eu-de.quantum.cloud.ibm.com/learning/en/courses/fundamentals-of-quantum-algorithms/quantum-query-algorithms/deutsch-jozsa-algorithm).

Ôn từ lớp nhập môn: [Qua một cổng Hadamard, qubit ở 0 sẽ ra sao?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-21-mot-cong-hadamard/) · [Đánh dấu ô đúng chỉ bằng cách đổi dấu ra sao?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-33-danh-dau-dap-an-bang-pha/).

[Về mục lục](muc-luc.md)
