# Bài 16 · Một nhịp 3/8 vòng hiện thành số 3 như thế nào?

## Đặt vấn đề

Một mặt đồng hồ chia tám vạch. Mỗi nhịp kim nhảy ba vạch. Nếu chỉ nhìn từng ảnh chụp và đếm độ dài kim, ảnh nào cũng cho cùng kết quả. Muốn tìm nhịp nhảy, mình thử tám mẫu quay khác nhau rồi xem mẫu nào làm mọi mũi đứng yên so với nó. Fourier ngược thực hiện đúng phép so pha đó.

Giả sử đã có một phép biến đổi $U$ và trạng thái riêng $|u\rangle$ với $U|u\rangle=e^{2\pi i\varphi}|u\rangle$. Chuẩn bị thanh ghi đếm ở chồng chập đều của tám giá trị $x$. Trên ba bit đếm, lần lượt điều khiển $U$, $U^2$, $U^4$ theo trọng số nhị phân. Nhánh $x=5$ bật trọng số 1 và 4 nên đích nhận $U^5$. Đích ở trạng thái riêng, vì vậy phụ thuộc vào $x$ chỉ còn pha. Cột thanh ghi đầu có hệ số $e^{2\pi i x\varphi}/\sqrt8$ ở hàng $x$.
$$
a_y=\frac{1}{Q}\sum_{x=0}^{Q-1}e^{2\pi i x(\varphi-y/Q)},\qquad Q=2^t.
$$
$Q$ là số nhãn của $t$ bit đếm, $\varphi$ tính theo vòng và $y$ là nhãn đo. Với $\varphi=3/8$, $y=3$ làm hiệu số trong ngoặc bằng 0 nên tám mũi cùng hướng, $a_3=1$. Với $y=2$, hiệu là 1/8 vòng: tám mũi đi đủ một vòng và tổng bằng 0. Mọi $y\ne3$ khác cũng cho tổng bằng 0 qua tổng cấp số nhân. Hai hệ số chuẩn hóa $1/\sqrt8$ ở hai đầu tạo ra $1/8$ trước tổng.

![Phổ của hai pha trên lưới tám điểm](hinh/hinh-16.webp)

*Giữ cùng thanh ghi rồi đổi nhịp từ 3/8 sang 1/3. Nhịp thứ hai không vừa lưới nên nhiều đầu ra cùng có xác suất dương.*

## Kiểm chứng bằng Python

Đổi dấu trong số mũ của tín hiệu rồi chạy lại. Với pha 3/8, đỉnh sẽ đổi từ nhãn 3 sang nhãn 5.

```python
import numpy as np
Q = 8
for phase in (3/8, 1/3):
    signal = np.exp(2j*np.pi*np.arange(Q)*phase)
    # fft dùng dấu trừ, đúng với QFT ngược theo quy ước của bài.
    p = np.abs(np.fft.fft(signal)/Q)**2
    print(f"φ={phase:.4f}", np.round(p, 4))
    assert np.isclose(p.sum(), 1)
```

Kết quả của lần chạy trong sổ thực hành:

```text
φ=0.3750 [0. 0. 0. 1. 0. 0. 0. 0.]
φ=0.3333 [0.0156 0.0316 0.1749 0.6878 0.0469 0.0186 0.0126 0.0119]
```

## Tự thử

Thấy $y=3$ có đủ kết luận pha đúng bằng 3/8 không?

**Lời giải.** Chỉ khi đã biết pha nằm đúng trên lưới tám điểm. Với pha 1/3, nhãn 3 cũng có thể xuất hiện. Tăng số bit đếm làm lưới mịn thêm. Nếu thanh ghi đích là chồng chập của nhiều trạng thái riêng, mỗi pha còn có một trọng số xác suất riêng. đây là trường hợp thực sự gặp trong bài tìm bậc.

## Tham khảo

- Nielsen & Chuang, *Quantum Computation and Quantum Information*, bản kỷ niệm 10 năm, chương 5. [Mục lục của Cambridge](https://assets.cambridge.org/97811070/02173/toc/9781107002173_toc.pdf).
- [IBM Quantum Learning · Ước lượng pha và phân tích thừa số](https://eu-de.quantum.cloud.ibm.com/learning/en/courses/fundamentals-of-quantum-algorithms/phase-estimation-and-factoring/introduction).

Ôn từ lớp nhập môn: [Làm sao biến một dãy lặp thành các đỉnh tần số?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-40-tu-chu-ky-den-dinh-tan-so/) · [Một lần đo sau biến đổi Fourier lượng tử trả về mẫu gì?](https://www.phamduytung.com/courses/may-tinh-luong-tu/bai-41-do-sau-bien-doi-fourier-luong-tu/).

[Về mục lục](muc-luc.md)
